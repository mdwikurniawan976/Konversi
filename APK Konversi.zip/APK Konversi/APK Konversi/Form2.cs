﻿using Bunifu.Framework.UI;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.ConstrainedExecution;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace APK_Konversi
{
    public partial class Form2 : Form
    {
        bool sidebarExpand;
        private decimal valueFirst = 0.0m;
        private decimal valueSecond = 0.0m;
        private decimal Result = 0.0m;
        private string operators = "+";
        private string FormatNumber(double number)
        {
            return number.ToString("#,0.########");

        } 
        public Form2()
        {
            InitializeComponent();

          
            // Menambahkan pilihan ukuran data ke ComboBox
           
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

     

        private void bunifuImageButton1_Click(object sender, EventArgs e)
        {
            bunifuPages1.SetPage(tabPage1);
        }

        private void button1_Click_6(object sender, EventArgs e)
        {

        }

      
    
        private void bunifuImageButton2_Click(object sender, EventArgs e)
        {
            bunifuPages1.SetPage(tabPage2);
        }


        private void bunifuImageButton3_Click(object sender, EventArgs e)
        {
            bunifuPages1.SetPage(tabPage3);
        }

        private void bunifuImageButton4_Click(object sender, EventArgs e)
        {
            bunifuPages1.SetPage(tabPage4);
        }

        private void bunifuImageButton5_Click(object sender, EventArgs e)
        {
            bunifuPages1.SetPage(tabPage5);
        }

        private void bunifuButton5_Click(object sender, EventArgs e)
        {
           
        }

        private void bunifuButton10_Click(object sender, EventArgs e)
        {
          
        }

        private void sidebarTimer1_Tick(object sender, EventArgs e)
        {
            if (sidebarExpand)
            {
                panel2.Width -= 10;
                if (panel2.Width == panel2.MinimumSize.Width)
                {
                    sidebarExpand = false;
                    sidebarTimer1.Stop();
                }
            }
            else
            {
                panel2.Width += 10;
                if (panel2.Width == panel2.MaximumSize.Width)
                {
                    sidebarExpand = true;
                    sidebarTimer1.Stop();
                }
            }
        }


     
        private void pictureBox1_Click(object sender, EventArgs e)
        {
            // picturre box
            sidebarTimer1.Start();
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void bunifuImageButton6_Click(object sender, EventArgs e)
        {
            this.Close();   
        }

        private void bunifuImageButton7_Click(object sender, EventArgs e)
        {
            if (this.WindowState == FormWindowState.Normal)
            {
                this.WindowState = FormWindowState.Maximized;
            }
            else
            {
                this.WindowState = FormWindowState.Normal;
            }
        }
            private void bunifuImageButton8_Click(object sender, EventArgs e)
            {
                this.WindowState = FormWindowState.Minimized;
            }

        private void tabPage5_Click(object sender, EventArgs e)
        {

        }

        private double ConvertVolume(double volume, string fromUnit, string toUnit)
        {
            // Implementasikan logika konversi sesuai dengan satuan yang dipilih
            switch (fromUnit)
            {
                case "Liter":
                    switch (toUnit)
                    {
                        case "Milliliter":
                            return volume * 1000;
                        case "Cubic Meter":
                            return volume / 1000;
                        default:
                            return volume;
                    }
                case "Milliliter":
                    switch (toUnit)
                    {
                        case "Liter":
                            return volume / 1000;
                        case "Cubic Meter":
                            return volume / 1000000;
                        default:
                            return volume;
                    }
                case "Cubic Meter":
                    switch (toUnit)
                    {
                        case "Liter":
                            return volume * 1000;
                        case "Milliliter":
                            return volume * 1000000;
                        default:
                            return volume;
                    }
                default:
                    return volume;
            }
        }
    

        private void bunifuButton6_Click(object sender, EventArgs e)
        {
           
        }
    

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void bunifuButton1_Click(object sender, EventArgs e)
        {
           
        }

        private void bunifuButton2_Click(object sender, EventArgs e)
        {
           
        }

        private void tabPage6_Click(object sender, EventArgs e)
        {

        }

        private void bunifuImageButton9_Click(object sender, EventArgs e)
        {
            bunifuPages1.SetPage(tabPage6);
        }

        private void textBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back;
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
         
        }

        private void celcius_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void celcius_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back;
        }

        private void fahrenheit_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back;
        }

        private void reamur_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back;
        }

        private void kelvin_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back;
        }

        private void bunifuTextBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void bunifuTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back;
        }

        private void bunifuTextBox3_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void bunifuTextBox3_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back;
        }

        private void bunifuTextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void bunifuTextBox2_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back;
        }

        private void bunifuTextBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void bunifuTextBox6_KeyPress(object sender, KeyPressEventArgs e)
        {
            e.Handled = !char.IsDigit(e.KeyChar) && e.KeyChar != (char)Keys.Back;
        }

        private void bunifuImageButton10_Click(object sender, EventArgs e)
        {
            bunifuPages1.SetPage(tabPage7);
        }

        private void bunifuImageButton11_Click(object sender, EventArgs e)
        {
            bunifuPages1.SetPage(tabPage8);
        }
        // Konversi Data
     
        private double ConvertDataSize(double value, string fromUnit, string toUnit)
        {
            string[] units = { "Byte", "Kilobyte", "Megabyte", "Gigabyte" , "Terabytes"};
            double[] multipliers = { 1, 1024, 1024 * 1024, 1024 * 1024 * 1024 };

            int fromIndex = Array.IndexOf(units, fromUnit);
            int toIndex = Array.IndexOf(units, toUnit);

            double convertedValue = value * multipliers[fromIndex] / multipliers[toIndex];
            return convertedValue;
        }
    

    private void ZeroBtn_Click(object sender, EventArgs e)
        {
            if(TxtBox.Text == "0")
            {
                TxtBox.Text = "0";
            }
            else
            {
                TxtBox.Text += "0";
            }
        }

        private void DotBtn_Click(object sender, EventArgs e)
        {
            if(!TxtBox.Text.Contains("."))
            {
                TxtBox.Text += ".";
            }
        }

        private void OneBtn_Click(object sender, EventArgs e)
        {
            if(TxtBox.Text == "0")
            {
                TxtBox.Text ="1";
            }
            else
            {
                TxtBox.Text += "1";
            }
        }

        private void TwoBtn_Click(object sender, EventArgs e)
        {
            if (TxtBox.Text == "0")
            {
                TxtBox.Text = "2";
            }
            else
            {
                TxtBox.Text += "2";
            }
        }

        private void ThreeBtn_Click(object sender, EventArgs e)
        {
            if (TxtBox.Text == "0")
            {
                TxtBox.Text = "3";
            }
            else
            {
                TxtBox.Text += "3";
            }
        }

        private void comboBox10_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void panel3_Paint(object sender, PaintEventArgs e)
        {

        }

        private void comboBox9_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (double.TryParse(bunifuTextBox6.Text, out double inputValue))
            {
                double convertedValue = ConvertArea(inputValue, comboBox8.SelectedItem.ToString(), comboBox9.SelectedItem.ToString());
                bunifuTextBox7.Text = convertedValue.ToString("0.###");
            }
            else
            {
                MessageBox.Show("Masukkan angka yang valid.");
            }
        }


        private void comboBox7_SelectedIndexChanged(object sender, EventArgs e)
        {
            string valueN = comboBox6.SelectedItem.ToString();
            string valueH = comboBox7.SelectedItem.ToString();
            double nilai = double.Parse(textBox1.Text);
            double hasil = 0;

            string[] unit = {  "kg", "hg", "dag", "g", "dg", "cg", "mg" };
            double[] multipliers = { 1, 10, 100, 1000, 10000, 100000, 1000000 };

            int indexvalueN = Array.IndexOf(unit, valueN);
            int indexvalueH = Array.IndexOf(unit, valueH);

            if (indexvalueN >= 0 && indexvalueH >= 0)
            {
                hasil = nilai * (multipliers[indexvalueH] / multipliers[indexvalueN]);
            }

            textBox2.Text = FormatNumber(hasil);
  
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            string valueN = comboBox1.SelectedItem.ToString();
            string valueH = comboBox2.SelectedItem.ToString();
            double nilai = double.Parse(bunifuTextBox1.Text);
            double hasil = 0;

            string[] unit = { "km (kilometer)", "hm (hektometer)", "dam (dekameter)", "m (meter)", "dm (desimeter)", "cm (centimeter)", "mm (milimeter)" };
            double[] multipliers = { 1, 10, 100, 1000, 10000, 100000, 1000000 };

            int indexvalueN = Array.IndexOf(unit, valueN);
            int indexvalueH = Array.IndexOf(unit, valueH);

            if (indexvalueN >= 0 && indexvalueH >= 0)
            {
                hasil = nilai * (multipliers[indexvalueH] / multipliers[indexvalueN]);
            }

           bunifuTextBox4.Text = FormatNumber(hasil);
        }
      

        private void comboBox5_SelectedIndexChanged(object sender, EventArgs e)
        {
           
        }

        private void FourBtn_Click(object sender, EventArgs e)
        {
            if (TxtBox.Text == "0")
            {
                TxtBox.Text = "4";
            }
            else
            {
                TxtBox.Text += "4";
            }
        }

        private void FiveBtn_Click(object sender, EventArgs e)
        {

            if (TxtBox.Text == "0")
            {
                TxtBox.Text = "5";
            }
            else
            {
                TxtBox.Text += "5";
            }
        }

        private void SixBtn_Click(object sender, EventArgs e)
        {

            if (TxtBox.Text == "0")
            {
                TxtBox.Text = "6";
            }
            else
            {
                TxtBox.Text += "6";
            }
        }

        private void SevenBtn_Click(object sender, EventArgs e)
        {

            if (TxtBox.Text == "0")
            {
                TxtBox.Text = "7";
            }
            else
            {
                TxtBox.Text += "7";
            }
        }

        private void EightBtn_Click(object sender, EventArgs e)
        {

            if (TxtBox.Text == "0")
            {
                TxtBox.Text = "8";
            }
            else
            {
                TxtBox.Text += "8";
            }
        }

        private void NineBtn_Click(object sender, EventArgs e)
        {

            if (TxtBox.Text == "0")
            {
                TxtBox.Text = "9";
            }
            else
            {
                TxtBox.Text += "9";
            }
        }

        private void ClearBtn_Click(object sender, EventArgs e)
        {
            valueFirst = 0.0m;
            valueSecond = 0.0m;
            TxtBox.Text = "0";
        }

        private void EqualBtn_Click(object sender, EventArgs e)
        {
            switch (operators)
            {
                case "-":
                    valueSecond = decimal.Parse(TxtBox.Text);
                    Result = valueFirst - valueSecond;
                    TxtBox.Text = Result.ToString();
                    break;
                case "+":
                    valueSecond = decimal.Parse(TxtBox.Text);
                    Result = valueFirst + valueSecond;
                    TxtBox.Text = Result.ToString();
                    break;
                case "*":
                    valueSecond = decimal.Parse(TxtBox.Text);
                    Result = valueFirst * valueSecond;
                    TxtBox.Text = Result.ToString();
                    break;
                case "/":
                    valueSecond = decimal.Parse(TxtBox.Text);
                    Result = valueFirst / valueSecond;
                    TxtBox.Text = Result.ToString();
                    break;
                case "%":
                    valueSecond = decimal.Parse(TxtBox.Text);
                    Result = valueFirst % valueSecond;
                    TxtBox.Text = Result.ToString();
                    break;
            }
        }

        private void MinusBtn_Click(object sender, EventArgs e)
        {
            valueFirst = decimal.Parse(TxtBox.Text);
            TxtBox.Clear();
            operators = "-";
        }

        private void PlusBtn_Click(object sender, EventArgs e)
        {
            valueFirst = decimal.Parse(TxtBox.Text);
            TxtBox.Clear();
            operators = "+";
        }

        private void DivideBtn_Click(object sender, EventArgs e)
        {
            valueFirst = decimal.Parse(TxtBox.Text);
            TxtBox.Clear();
            operators = "/";
        }

        private void MultipleBtn_Click(object sender, EventArgs e)
        {
            valueFirst = decimal.Parse(TxtBox.Text);
            TxtBox.Clear();
            operators = "*";
        }

        private void PlusminusBtn_Click(object sender, EventArgs e)
        {

            if (TxtBox.Text.Contains(""))
            {
                TxtBox.Text = TxtBox.Text.Trim('-');
            }
            else
            {
                TxtBox.Text = "-" + TxtBox.Text;
            }

        }

        private void tabPage8_Click(object sender, EventArgs e)
        {

        }

        private void PercentBtn_Click(object sender, EventArgs e)
        {
            valueFirst = decimal.Parse(TxtBox.Text);
            TxtBox.Clear();
            operators = "%";
        }

        private void comboBox11_SelectedIndexChanged(object sender, EventArgs e)
        {
            string value = comboBox10.SelectedItem.ToString();
            string valueh= comboBox11.SelectedItem.ToString();

            double nilai = double.Parse(bunifuTextBox8.Text);
            double hasil = 0;

            string[] unit = { "TB (terabyte)", "GB (gigabyte)", "MB (megabyte)", "KB (kilobyte)" };
            double[] multipliers = { 1, 1000, 1000000, 1000000000 };

            int indexvalueN = Array.IndexOf(unit, value);
            int indexvalueH = Array.IndexOf(unit, valueh);

            if (indexvalueN >= 0 && indexvalueH >= 0)
            {
                hasil = nilai * (multipliers[indexvalueH] / multipliers[indexvalueN]);
            }

            bunifuTextBox9.Text = FormatNumber(hasil);

        }

        private double ConvertArea(double value, string fromUnit, string toUnit)
        {
            string[] units = { "Meter Persegi", "Kilometer Persegi", "Hektar", "Acre" };
            double[] multipliers = { 1, 1000000, 10000, 4046.86 };

            int fromIndex = Array.IndexOf(units, fromUnit);
            int toIndex = Array.IndexOf(units, toUnit);

            double convertedValue = value * multipliers[fromIndex] / multipliers[toIndex];
            return convertedValue;
        }

        private void bunifuTextBox8_TextChanged(object sender, EventArgs e)
        {

        }

        private void tabPage7_Click(object sender, EventArgs e)
        {

        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void comboBoxTo_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (double.TryParse(textBoxValue.Text, out double inputValue))
            {
                double result = 0.0;

                string fromUnit = comboBoxFrom.SelectedItem.ToString();
                string toUnit = comboBoxTo.SelectedItem.ToString();

                // Konversi suhu sesuai pilihan
                switch (fromUnit)
                {
                    case "Celsius":
                        result = ConvertCelsiusTo(toUnit, inputValue);
                        break;
                    case "Fahrenheit":
                        result = ConvertFahrenheitTo(toUnit, inputValue);
                        break;
                    case "Kelvin":
                        result = ConvertKelvinTo(toUnit, inputValue);
                        break;
                    case "Reamur":
                        result = ConvertReamurTo(toUnit, inputValue);
                        break;
                }

                textBoxResult.Text = result.ToString();
            }
            else
            {
                textBoxResult.Text = "Invalid input";
            }
        }

        private double ConvertCelsiusTo(string toUnit, double value)
        {
            switch (toUnit)
            {
                case "Fahrenheit":
                    return (value * 9 / 5) + 32;
                case "Kelvin":
                    return value + 273.15;
                case "Reamur":
                    return value * 4 / 5;
                default:
                    return value;
            }
        }

        private void bunifuTextBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox12_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (double.TryParse(bunifuTextBox3.Text, out double inputValue))
            {
                string selectedUnit = comboBox5.SelectedItem.ToString();
                string convertToUnit = comboBox12.SelectedItem.ToString();

                double result = ConvertTime(inputValue, selectedUnit, convertToUnit);
                bunifuTextBox5.Text = result.ToString();
            }
            else
            {
                MessageBox.Show("Masukkan angka valid untuk konversi waktu.", "Kesalahan", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private double ConvertTime(double value, string fromUnit, string toUnit)
        {
            double conversionFactor = GetConversionFactor(fromUnit, toUnit);
            return value * conversionFactor;
        }
        private double GetConversionFactor(string fromUnit, string toUnit)
        {
            switch (fromUnit)
            {
                case "Detik":
                    return GetConversionFactorFromSeconds(toUnit);
                case "Menit":
                    return GetConversionFactorFromMinutes(toUnit);
                case "Jam":
                    return GetConversionFactorFromHours(toUnit);
                case "Hari":
                    return GetConversionFactorFromDays(toUnit);
                case "Bulan":
                    return GetConversionFactorFromMonths(toUnit);
                case "Tahun":
                    return GetConversionFactorFromYears(toUnit);
                default:
                    return 1.0;
            }
        }
        private double GetConversionFactorFromSeconds(string toUnit)
        {
            switch (toUnit)
            {
                case "Detik":
                    return 1.0;
                case "Menit":
                    return 1.0 / 60.0;
                case "Jam":
                    return 1.0 / 3600.0;
                case "Hari":
                    return 1.0 / 86400.0;
                case "Bulan":
                    return 1.0 / (86400.0 * 30.0); // Perkiraan 30 hari per bulan
                case "Tahun":
                    return 1.0 / (86400.0 * 365.0); // Perkiraan 365 hari per tahun
                default:
                    return 1.0;
            }
        }
        private double GetConversionFactorFromMinutes(string toUnit)
        {
            switch(toUnit)
            {
                case "Detik":
                   return 1 * 60.0;
                    case "Menit":
                    return 1 ;
                case "Jam":
                    return 1 * 60;
                case "Hari":
                    return 1 / 1440;
                case "Bulan":
                    return 1 / (43800 * 30.0); // Perkiraan 30 hari per bulan
                case "Tahun":
                    return 1 / (525600 * 365.0); // Perkiraan 365 hari per tahun
                default:
                    return 1;
            }
        }
        private double GetConversionFactorFromHours(string toUnit)
        {
            switch (toUnit)
            {
                case "Detik":
                    return 1 * 3600;
                case "Menit":
                    return 1;
                case "Jam":
                    return 1 ;
                case "Hari":
                    return 1 / 24;
                case "Bulan":
                    return 1 / (730 * 30.0); // Perkiraan 30 hari per bulan
                case "Tahun":
                    return 1 / (8760 * 365.0); // Perkiraan 365 hari per tahun
                default:
                    return 1;
            }
        }

        // BELUMMMMM
        private double GetConversionFactorFromDays(string toUnit)
        {
            switch (toUnit)
            {
                case "Detik":
                    return 1 * 86400;
                case "Menit":
                    return 1;
                case "Jam":
                    return 1 * 1440 ;
                case "Hari":
                    return 1 ;
                case "Bulan":
                    return 1 / (30.417 * 30.0); // Perkiraan 30 hari per bulan
                case "Tahun":
                    return 1 / (8760 * 365.0); // Perkiraan 365 hari per tahun
                default:
                    return 1;
            }
        }
        private double GetConversionFactorFromMonths(string toUnit)
        {
            switch (toUnit)
            {
                case "Detik":
                    return 1 * 3600;
                case "Menit":
                    return 1;
                case "Jam":
                    return 1 * 60;
                case "Hari":
                    return 1 / 24;
                case "Bulan":
                    return 1 / (730 * 30.0); // Perkiraan 30 hari per bulan
                case "Tahun":
                    return 1 / (8760 * 365.0); // Perkiraan 365 hari per tahun
                default:
                    return 1;
            }
        }
        private double GetConversionFactorFromYears(string toUnit)
        {
            switch (toUnit)
            {
                case "Detik":
                    return 1 * 3600;
                case "Menit":
                    return 1;
                case "Jam":
                    return 1 * 60;
                case "Hari":
                    return 1 / 24;
                case "Bulan":
                    return 1 / (730 * 30.0); // Perkiraan 30 hari per bulan
                case "Tahun":
                    return 1 / (8760 * 365.0); // Perkiraan 365 hari per tahun
                default:
                    return 1;
            }
        }
        private double ConvertFahrenheitTo(string toUnit, double value)
        {
            switch (toUnit)
            {
                case "Celsius":
                    return (value - 32) * 5 / 9;
                case "Kelvin":
                    return (value + 459.67) * 5 / 9;
                case "Reamur":
                    return (value - 32) * 4 / 9;
                default:
                    return value;
            }
        }

        private double ConvertKelvinTo(string toUnit, double value)
        {
            switch (toUnit)
            {
                case "Celsius":
                    return value - 273.15;
                case "Fahrenheit":
                    return (value * 9 / 5) - 459.67;
                case "Reamur":
                    return (value - 273.15) * 4 / 5;
                default:
                    return value;
            }
        }

        private double ConvertReamurTo(string toUnit, double value)
        {
            switch (toUnit)
            {
                case "Celsius":
                    return value * 5 / 4;
                case "Fahrenheit":
                    return (value * 9 / 4) + 32;
                case "Kelvin":
                    return (value * 5 / 4) + 273.15;
                default:
                    return value;
            }
        }

        private void label10_Click(object sender, EventArgs e)
        {

        }

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (double.TryParse(bunifuTextBox2.Text, out double inputVolume))
            {
                // Konversi volume berdasarkan pilihan satuan
                double resultVolume = ConvertVolume(inputVolume, comboBox3.SelectedItem.ToString(), comboBox4.SelectedItem.ToString());
                MessageBox.Show($"{inputVolume} {comboBox3.SelectedItem} = {resultVolume} {comboBox4.SelectedItem}", "Hasil Konversi");
            }
            else
            {
                MessageBox.Show("Masukkan angka yang valid untuk volume.", "Error");
            }
            // bunifuTextBox6.Text = ($"{inputVolume} {comboBox3.SelectedItem} = {resultVolume} {comboBox4.SelectedItem}", "Hasil Konversi");
        }
    }
}
  

