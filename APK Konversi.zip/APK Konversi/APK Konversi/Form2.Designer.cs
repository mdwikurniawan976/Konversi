﻿namespace APK_Konversi
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            Utilities.BunifuPages.BunifuAnimatorNS.Animation animation2 = new Utilities.BunifuPages.BunifuAnimatorNS.Animation();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form2));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties41 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties42 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties43 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties44 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties45 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties46 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties47 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties48 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties49 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties50 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties51 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties52 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties53 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties54 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties55 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties56 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties57 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties58 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties59 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties60 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties61 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties62 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties63 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties64 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties65 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties66 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties67 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties68 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties69 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties70 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties71 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties72 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties73 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties74 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties75 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties76 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges20 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges21 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges22 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges23 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges24 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges25 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges26 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges27 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges28 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges29 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges30 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges31 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges32 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges33 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges34 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges35 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges36 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges37 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges38 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties77 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties78 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties79 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties80 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.bunifuPages1 = new Bunifu.UI.WinForms.BunifuPages();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.label18 = new System.Windows.Forms.Label();
            this.comboBox7 = new System.Windows.Forms.ComboBox();
            this.comboBox6 = new System.Windows.Forms.ComboBox();
            this.label17 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.label4 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.label43 = new System.Windows.Forms.Label();
            this.comboBoxTo = new System.Windows.Forms.ComboBox();
            this.comboBoxFrom = new System.Windows.Forms.ComboBox();
            this.textBoxResult = new System.Windows.Forms.TextBox();
            this.textBoxValue = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.comboBox2 = new System.Windows.Forms.ComboBox();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.bunifuTextBox4 = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuTextBox1 = new Bunifu.UI.WinForms.BunifuTextBox();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.label44 = new System.Windows.Forms.Label();
            this.comboBox12 = new System.Windows.Forms.ComboBox();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.comboBox5 = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.bunifuTextBox5 = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuTextBox3 = new Bunifu.UI.WinForms.BunifuTextBox();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.label38 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.comboBox4 = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.bunifuTextBox2 = new Bunifu.UI.WinForms.BunifuTextBox();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.label39 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.comboBox9 = new System.Windows.Forms.ComboBox();
            this.label22 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.bunifuTextBox7 = new Bunifu.UI.WinForms.BunifuTextBox();
            this.comboBox8 = new System.Windows.Forms.ComboBox();
            this.bunifuTextBox6 = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.tabPage7 = new System.Windows.Forms.TabPage();
            this.label27 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.comboBox11 = new System.Windows.Forms.ComboBox();
            this.comboBox10 = new System.Windows.Forms.ComboBox();
            this.bunifuTextBox9 = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuTextBox8 = new Bunifu.UI.WinForms.BunifuTextBox();
            this.label26 = new System.Windows.Forms.Label();
            this.tabPage8 = new System.Windows.Forms.TabPage();
            this.PercentBtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.PlusminusBtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.MultipleBtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.PlusBtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.DivideBtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.MinusBtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.ClearBtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.EqualBtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.DotBtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.ZeroBtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.SixBtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.OneBtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.TwoBtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.ThreeBtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.FourBtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.FiveBtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.NineBtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.EightBtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.SevenBtn = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.TxtBox = new Bunifu.UI.WinForms.BunifuTextBox();
            this.panel3 = new System.Windows.Forms.Panel();
            this.bunifuImageButton8 = new Bunifu.UI.WinForms.BunifuImageButton();
            this.bunifuImageButton7 = new Bunifu.UI.WinForms.BunifuImageButton();
            this.bunifuImageButton6 = new Bunifu.UI.WinForms.BunifuImageButton();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.panel2 = new System.Windows.Forms.Panel();
            this.label25 = new System.Windows.Forms.Label();
            this.bunifuImageButton11 = new Bunifu.UI.WinForms.BunifuImageButton();
            this.label24 = new System.Windows.Forms.Label();
            this.bunifuImageButton10 = new Bunifu.UI.WinForms.BunifuImageButton();
            this.label23 = new System.Windows.Forms.Label();
            this.bunifuImageButton9 = new Bunifu.UI.WinForms.BunifuImageButton();
            this.label13 = new System.Windows.Forms.Label();
            this.label12 = new System.Windows.Forms.Label();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.bunifuImageButton5 = new Bunifu.UI.WinForms.BunifuImageButton();
            this.bunifuImageButton4 = new Bunifu.UI.WinForms.BunifuImageButton();
            this.bunifuImageButton3 = new Bunifu.UI.WinForms.BunifuImageButton();
            this.bunifuImageButton2 = new Bunifu.UI.WinForms.BunifuImageButton();
            this.bunifuImageButton1 = new Bunifu.UI.WinForms.BunifuImageButton();
            this.panel4 = new System.Windows.Forms.Panel();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.sidebarTimer1 = new System.Windows.Forms.Timer(this.components);
            this.bunifuDragControl1 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.bunifuDragControl2 = new Bunifu.Framework.UI.BunifuDragControl(this.components);
            this.panel1.SuspendLayout();
            this.panel5.SuspendLayout();
            this.bunifuPages1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.tabPage7.SuspendLayout();
            this.tabPage8.SuspendLayout();
            this.panel3.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            this.panel2.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel1.Controls.Add(this.panel5);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Controls.Add(this.panel2);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1075, 663);
            this.panel1.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.Controls.Add(this.bunifuPages1);
            this.panel5.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel5.Location = new System.Drawing.Point(359, 49);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(716, 614);
            this.panel5.TabIndex = 2;
            // 
            // bunifuPages1
            // 
            this.bunifuPages1.Alignment = System.Windows.Forms.TabAlignment.Bottom;
            this.bunifuPages1.AllowTransitions = true;
            this.bunifuPages1.Controls.Add(this.tabPage1);
            this.bunifuPages1.Controls.Add(this.tabPage2);
            this.bunifuPages1.Controls.Add(this.tabPage3);
            this.bunifuPages1.Controls.Add(this.tabPage4);
            this.bunifuPages1.Controls.Add(this.tabPage5);
            this.bunifuPages1.Controls.Add(this.tabPage6);
            this.bunifuPages1.Controls.Add(this.tabPage7);
            this.bunifuPages1.Controls.Add(this.tabPage8);
            this.bunifuPages1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuPages1.Location = new System.Drawing.Point(0, 0);
            this.bunifuPages1.Multiline = true;
            this.bunifuPages1.Name = "bunifuPages1";
            this.bunifuPages1.Page = this.tabPage1;
            this.bunifuPages1.PageIndex = 0;
            this.bunifuPages1.PageName = "tabPage1";
            this.bunifuPages1.PageTitle = "Massa";
            this.bunifuPages1.SelectedIndex = 0;
            this.bunifuPages1.Size = new System.Drawing.Size(716, 614);
            this.bunifuPages1.TabIndex = 0;
            animation2.AnimateOnlyDifferences = true;
            animation2.BlindCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.BlindCoeff")));
            animation2.LeafCoeff = 0F;
            animation2.MaxTime = 1F;
            animation2.MinTime = 0F;
            animation2.MosaicCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.MosaicCoeff")));
            animation2.MosaicShift = ((System.Drawing.PointF)(resources.GetObject("animation2.MosaicShift")));
            animation2.MosaicSize = 0;
            animation2.Padding = new System.Windows.Forms.Padding(0, 0, 0, 0);
            animation2.RotateCoeff = 0F;
            animation2.RotateLimit = 0F;
            animation2.ScaleCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.ScaleCoeff")));
            animation2.SlideCoeff = ((System.Drawing.PointF)(resources.GetObject("animation2.SlideCoeff")));
            animation2.TimeCoeff = 0F;
            animation2.TransparencyCoeff = 0F;
            this.bunifuPages1.Transition = animation2;
            this.bunifuPages1.TransitionType = Utilities.BunifuPages.BunifuAnimatorNS.AnimationType.HorizBlind;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.tabPage1.Controls.Add(this.label18);
            this.tabPage1.Controls.Add(this.comboBox7);
            this.tabPage1.Controls.Add(this.comboBox6);
            this.tabPage1.Controls.Add(this.label17);
            this.tabPage1.Controls.Add(this.label16);
            this.tabPage1.Controls.Add(this.label8);
            this.tabPage1.Controls.Add(this.textBox2);
            this.tabPage1.Controls.Add(this.label2);
            this.tabPage1.Controls.Add(this.textBox1);
            this.tabPage1.Location = new System.Drawing.Point(4, 4);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(708, 585);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Massa";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label18.ForeColor = System.Drawing.Color.White;
            this.label18.Location = new System.Drawing.Point(117, 160);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(52, 18);
            this.label18.TabIndex = 69;
            this.label18.Text = "Input :";
            // 
            // comboBox7
            // 
            this.comboBox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox7.FormattingEnabled = true;
            this.comboBox7.Items.AddRange(new object[] {
            "kg",
            "hg",
            "dag",
            "g",
            "dg ",
            "cg ",
            "mg"});
            this.comboBox7.Location = new System.Drawing.Point(180, 254);
            this.comboBox7.Name = "comboBox7";
            this.comboBox7.Size = new System.Drawing.Size(429, 37);
            this.comboBox7.TabIndex = 68;
            this.comboBox7.SelectedIndexChanged += new System.EventHandler(this.comboBox7_SelectedIndexChanged);
            // 
            // comboBox6
            // 
            this.comboBox6.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox6.FormattingEnabled = true;
            this.comboBox6.Items.AddRange(new object[] {
            "kg",
            "hg",
            "dag",
            "g",
            "dg ",
            "cg ",
            "mg"});
            this.comboBox6.Location = new System.Drawing.Point(180, 204);
            this.comboBox6.Name = "comboBox6";
            this.comboBox6.Size = new System.Drawing.Size(429, 37);
            this.comboBox6.TabIndex = 67;
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label17.ForeColor = System.Drawing.Color.White;
            this.label17.Location = new System.Drawing.Point(114, 317);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(50, 18);
            this.label17.TabIndex = 66;
            this.label17.Text = "Hasil :";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label16.ForeColor = System.Drawing.Color.White;
            this.label16.Location = new System.Drawing.Point(120, 260);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(35, 18);
            this.label16.TabIndex = 65;
            this.label16.Text = "Ke :";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.ForeColor = System.Drawing.Color.White;
            this.label8.Location = new System.Drawing.Point(111, 210);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(46, 18);
            this.label8.TabIndex = 64;
            this.label8.Text = "Dari :";
            // 
            // textBox2
            // 
            this.textBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox2.Location = new System.Drawing.Point(182, 309);
            this.textBox2.Name = "textBox2";
            this.textBox2.ReadOnly = true;
            this.textBox2.Size = new System.Drawing.Size(140, 34);
            this.textBox2.TabIndex = 63;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            this.textBox2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox2_KeyPress);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.White;
            this.label2.Location = new System.Drawing.Point(251, 3);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(222, 34);
            this.label2.TabIndex = 61;
            this.label2.Text = "Konversi Massa";
            // 
            // textBox1
            // 
            this.textBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBox1.Location = new System.Drawing.Point(179, 149);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(432, 34);
            this.textBox1.TabIndex = 57;
            this.textBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.textBox1_KeyPress);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.tabPage2.Controls.Add(this.label4);
            this.tabPage2.Controls.Add(this.label41);
            this.tabPage2.Controls.Add(this.label42);
            this.tabPage2.Controls.Add(this.label43);
            this.tabPage2.Controls.Add(this.comboBoxTo);
            this.tabPage2.Controls.Add(this.comboBoxFrom);
            this.tabPage2.Controls.Add(this.textBoxResult);
            this.tabPage2.Controls.Add(this.textBoxValue);
            this.tabPage2.Controls.Add(this.label3);
            this.tabPage2.Location = new System.Drawing.Point(4, 4);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(708, 585);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Suhu";
            this.tabPage2.Click += new System.EventHandler(this.tabPage2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.White;
            this.label4.Location = new System.Drawing.Point(82, 287);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(35, 18);
            this.label4.TabIndex = 84;
            this.label4.Text = "Ke :";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label41.ForeColor = System.Drawing.Color.White;
            this.label41.Location = new System.Drawing.Point(74, 243);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(46, 18);
            this.label41.TabIndex = 83;
            this.label41.Text = "Dari :";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.BackColor = System.Drawing.Color.Transparent;
            this.label42.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label42.ForeColor = System.Drawing.Color.White;
            this.label42.Location = new System.Drawing.Point(63, 335);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(58, 19);
            this.label42.TabIndex = 82;
            this.label42.Text = "Hasil :";
            // 
            // label43
            // 
            this.label43.AutoSize = true;
            this.label43.BackColor = System.Drawing.Color.Transparent;
            this.label43.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label43.ForeColor = System.Drawing.Color.White;
            this.label43.Location = new System.Drawing.Point(60, 197);
            this.label43.Name = "label43";
            this.label43.Size = new System.Drawing.Size(64, 19);
            this.label43.TabIndex = 81;
            this.label43.Text = "Input : ";
            // 
            // comboBoxTo
            // 
            this.comboBoxTo.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxTo.FormattingEnabled = true;
            this.comboBoxTo.Items.AddRange(new object[] {
            "Celsius",
            "Fahrenheit",
            "Reamur",
            "Kelvin"});
            this.comboBoxTo.Location = new System.Drawing.Point(130, 282);
            this.comboBoxTo.Name = "comboBoxTo";
            this.comboBoxTo.Size = new System.Drawing.Size(470, 30);
            this.comboBoxTo.TabIndex = 67;
            this.comboBoxTo.SelectedIndexChanged += new System.EventHandler(this.comboBoxTo_SelectedIndexChanged);
            // 
            // comboBoxFrom
            // 
            this.comboBoxFrom.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBoxFrom.FormattingEnabled = true;
            this.comboBoxFrom.Items.AddRange(new object[] {
            "Celsius",
            "Fahrenheit",
            "Reamur",
            "Kelvin"});
            this.comboBoxFrom.Location = new System.Drawing.Point(130, 237);
            this.comboBoxFrom.Name = "comboBoxFrom";
            this.comboBoxFrom.Size = new System.Drawing.Size(470, 30);
            this.comboBoxFrom.TabIndex = 66;
            // 
            // textBoxResult
            // 
            this.textBoxResult.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxResult.Location = new System.Drawing.Point(130, 331);
            this.textBoxResult.Name = "textBoxResult";
            this.textBoxResult.Size = new System.Drawing.Size(294, 30);
            this.textBoxResult.TabIndex = 55;
            this.textBoxResult.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.fahrenheit_KeyPress);
            // 
            // textBoxValue
            // 
            this.textBoxValue.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.textBoxValue.Location = new System.Drawing.Point(130, 193);
            this.textBoxValue.Name = "textBoxValue";
            this.textBoxValue.Size = new System.Drawing.Size(470, 30);
            this.textBoxValue.TabIndex = 53;
            this.textBoxValue.Text = " ";
            this.textBoxValue.TextChanged += new System.EventHandler(this.celcius_TextChanged);
            this.textBoxValue.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.celcius_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.White;
            this.label3.Location = new System.Drawing.Point(237, 3);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(203, 34);
            this.label3.TabIndex = 63;
            this.label3.Text = "Konversi Suhu";
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.tabPage3.Controls.Add(this.label28);
            this.tabPage3.Controls.Add(this.label29);
            this.tabPage3.Controls.Add(this.label30);
            this.tabPage3.Controls.Add(this.label31);
            this.tabPage3.Controls.Add(this.comboBox2);
            this.tabPage3.Controls.Add(this.comboBox1);
            this.tabPage3.Controls.Add(this.label5);
            this.tabPage3.Controls.Add(this.bunifuTextBox4);
            this.tabPage3.Controls.Add(this.bunifuTextBox1);
            this.tabPage3.Location = new System.Drawing.Point(4, 4);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Size = new System.Drawing.Size(708, 585);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Panjang";
            this.tabPage3.Click += new System.EventHandler(this.tabPage3_Click);
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label28.ForeColor = System.Drawing.Color.White;
            this.label28.Location = new System.Drawing.Point(76, 188);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(64, 22);
            this.label28.TabIndex = 73;
            this.label28.Text = "Input :";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.ForeColor = System.Drawing.Color.White;
            this.label29.Location = new System.Drawing.Point(79, 386);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(60, 22);
            this.label29.TabIndex = 72;
            this.label29.Text = "Hasil :";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.ForeColor = System.Drawing.Color.White;
            this.label30.Location = new System.Drawing.Point(85, 306);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(43, 22);
            this.label30.TabIndex = 71;
            this.label30.Text = "Ke :";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.ForeColor = System.Drawing.Color.White;
            this.label31.Location = new System.Drawing.Point(78, 250);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(55, 22);
            this.label31.TabIndex = 70;
            this.label31.Text = "Dari :";
            // 
            // comboBox2
            // 
            this.comboBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox2.FormattingEnabled = true;
            this.comboBox2.Items.AddRange(new object[] {
            "km (kilometer)",
            "hm (hektometer)",
            "dam (dekameter) ",
            "m (meter) ",
            "dm (desimeter)  ",
            "(centimeter)",
            " mm (milimeter) "});
            this.comboBox2.Location = new System.Drawing.Point(148, 301);
            this.comboBox2.Name = "comboBox2";
            this.comboBox2.Size = new System.Drawing.Size(464, 37);
            this.comboBox2.TabIndex = 52;
            this.comboBox2.SelectedIndexChanged += new System.EventHandler(this.comboBox2_SelectedIndexChanged);
            // 
            // comboBox1
            // 
            this.comboBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "km (kilometer)",
            "hm (hektometer)",
            "dam (dekameter) ",
            "m (meter) ",
            "dm (desimeter)  ",
            "(centimeter)",
            " mm (milimeter) "});
            this.comboBox1.Location = new System.Drawing.Point(148, 241);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(464, 37);
            this.comboBox1.TabIndex = 51;
            this.comboBox1.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.White;
            this.label5.Location = new System.Drawing.Point(202, 13);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(256, 34);
            this.label5.TabIndex = 47;
            this.label5.Text = "Konversi  Panjang";
            // 
            // bunifuTextBox4
            // 
            this.bunifuTextBox4.AcceptsReturn = false;
            this.bunifuTextBox4.AcceptsTab = false;
            this.bunifuTextBox4.AnimationSpeed = 200;
            this.bunifuTextBox4.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox4.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox4.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox4.BackgroundImage")));
            this.bunifuTextBox4.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.bunifuTextBox4.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuTextBox4.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuTextBox4.BorderColorIdle = System.Drawing.Color.Silver;
            this.bunifuTextBox4.BorderRadius = 1;
            this.bunifuTextBox4.BorderThickness = 1;
            this.bunifuTextBox4.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox4.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox4.DefaultFont = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuTextBox4.DefaultText = "";
            this.bunifuTextBox4.FillColor = System.Drawing.Color.White;
            this.bunifuTextBox4.HideSelection = true;
            this.bunifuTextBox4.IconLeft = null;
            this.bunifuTextBox4.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox4.IconPadding = 10;
            this.bunifuTextBox4.IconRight = null;
            this.bunifuTextBox4.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox4.Lines = new string[0];
            this.bunifuTextBox4.Location = new System.Drawing.Point(148, 374);
            this.bunifuTextBox4.MaxLength = 32767;
            this.bunifuTextBox4.MinimumSize = new System.Drawing.Size(1, 1);
            this.bunifuTextBox4.Modified = false;
            this.bunifuTextBox4.Multiline = false;
            this.bunifuTextBox4.Name = "bunifuTextBox4";
            stateProperties41.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties41.FillColor = System.Drawing.Color.Empty;
            stateProperties41.ForeColor = System.Drawing.Color.Empty;
            stateProperties41.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox4.OnActiveState = stateProperties41;
            stateProperties42.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties42.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties42.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties42.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.bunifuTextBox4.OnDisabledState = stateProperties42;
            stateProperties43.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties43.FillColor = System.Drawing.Color.Empty;
            stateProperties43.ForeColor = System.Drawing.Color.Empty;
            stateProperties43.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox4.OnHoverState = stateProperties43;
            stateProperties44.BorderColor = System.Drawing.Color.Silver;
            stateProperties44.FillColor = System.Drawing.Color.White;
            stateProperties44.ForeColor = System.Drawing.Color.Empty;
            stateProperties44.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox4.OnIdleState = stateProperties44;
            this.bunifuTextBox4.Padding = new System.Windows.Forms.Padding(3);
            this.bunifuTextBox4.PasswordChar = '\0';
            this.bunifuTextBox4.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.bunifuTextBox4.PlaceholderText = "Enter text";
            this.bunifuTextBox4.ReadOnly = true;
            this.bunifuTextBox4.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.bunifuTextBox4.SelectedText = "";
            this.bunifuTextBox4.SelectionLength = 0;
            this.bunifuTextBox4.SelectionStart = 0;
            this.bunifuTextBox4.ShortcutsEnabled = true;
            this.bunifuTextBox4.Size = new System.Drawing.Size(337, 43);
            this.bunifuTextBox4.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox4.TabIndex = 55;
            this.bunifuTextBox4.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox4.TextMarginBottom = 0;
            this.bunifuTextBox4.TextMarginLeft = 3;
            this.bunifuTextBox4.TextMarginTop = 0;
            this.bunifuTextBox4.TextPlaceholder = "Enter text";
            this.bunifuTextBox4.UseSystemPasswordChar = false;
            this.bunifuTextBox4.WordWrap = true;
            // 
            // bunifuTextBox1
            // 
            this.bunifuTextBox1.AcceptsReturn = false;
            this.bunifuTextBox1.AcceptsTab = false;
            this.bunifuTextBox1.AnimationSpeed = 200;
            this.bunifuTextBox1.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox1.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox1.BackgroundImage")));
            this.bunifuTextBox1.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.bunifuTextBox1.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuTextBox1.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuTextBox1.BorderColorIdle = System.Drawing.Color.Silver;
            this.bunifuTextBox1.BorderRadius = 1;
            this.bunifuTextBox1.BorderThickness = 1;
            this.bunifuTextBox1.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox1.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox1.DefaultFont = new System.Drawing.Font("Century Gothic", 10.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuTextBox1.DefaultText = "";
            this.bunifuTextBox1.FillColor = System.Drawing.Color.White;
            this.bunifuTextBox1.HideSelection = true;
            this.bunifuTextBox1.IconLeft = null;
            this.bunifuTextBox1.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox1.IconPadding = 10;
            this.bunifuTextBox1.IconRight = null;
            this.bunifuTextBox1.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox1.Lines = new string[0];
            this.bunifuTextBox1.Location = new System.Drawing.Point(148, 177);
            this.bunifuTextBox1.MaxLength = 32767;
            this.bunifuTextBox1.MinimumSize = new System.Drawing.Size(1, 1);
            this.bunifuTextBox1.Modified = false;
            this.bunifuTextBox1.Multiline = false;
            this.bunifuTextBox1.Name = "bunifuTextBox1";
            stateProperties45.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties45.FillColor = System.Drawing.Color.Empty;
            stateProperties45.ForeColor = System.Drawing.Color.Empty;
            stateProperties45.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox1.OnActiveState = stateProperties45;
            stateProperties46.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties46.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties46.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties46.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.bunifuTextBox1.OnDisabledState = stateProperties46;
            stateProperties47.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties47.FillColor = System.Drawing.Color.Empty;
            stateProperties47.ForeColor = System.Drawing.Color.Empty;
            stateProperties47.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox1.OnHoverState = stateProperties47;
            stateProperties48.BorderColor = System.Drawing.Color.Silver;
            stateProperties48.FillColor = System.Drawing.Color.White;
            stateProperties48.ForeColor = System.Drawing.Color.Empty;
            stateProperties48.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox1.OnIdleState = stateProperties48;
            this.bunifuTextBox1.Padding = new System.Windows.Forms.Padding(3);
            this.bunifuTextBox1.PasswordChar = '\0';
            this.bunifuTextBox1.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.bunifuTextBox1.PlaceholderText = "Enter text";
            this.bunifuTextBox1.ReadOnly = false;
            this.bunifuTextBox1.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.bunifuTextBox1.SelectedText = "";
            this.bunifuTextBox1.SelectionLength = 0;
            this.bunifuTextBox1.SelectionStart = 0;
            this.bunifuTextBox1.ShortcutsEnabled = true;
            this.bunifuTextBox1.Size = new System.Drawing.Size(464, 43);
            this.bunifuTextBox1.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox1.TabIndex = 48;
            this.bunifuTextBox1.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox1.TextMarginBottom = 0;
            this.bunifuTextBox1.TextMarginLeft = 3;
            this.bunifuTextBox1.TextMarginTop = 0;
            this.bunifuTextBox1.TextPlaceholder = "Enter text";
            this.bunifuTextBox1.UseSystemPasswordChar = false;
            this.bunifuTextBox1.WordWrap = true;
            this.bunifuTextBox1.TextChanged += new System.EventHandler(this.bunifuTextBox1_TextChanged);
            this.bunifuTextBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.bunifuTextBox1_KeyPress);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.tabPage4.Controls.Add(this.label44);
            this.tabPage4.Controls.Add(this.comboBox12);
            this.tabPage4.Controls.Add(this.label14);
            this.tabPage4.Controls.Add(this.label15);
            this.tabPage4.Controls.Add(this.label32);
            this.tabPage4.Controls.Add(this.comboBox5);
            this.tabPage4.Controls.Add(this.label7);
            this.tabPage4.Controls.Add(this.bunifuTextBox5);
            this.tabPage4.Controls.Add(this.bunifuTextBox3);
            this.tabPage4.Location = new System.Drawing.Point(4, 4);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Size = new System.Drawing.Size(708, 585);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "Waktu";
            // 
            // label44
            // 
            this.label44.AutoSize = true;
            this.label44.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label44.ForeColor = System.Drawing.Color.White;
            this.label44.Location = new System.Drawing.Point(76, 278);
            this.label44.Name = "label44";
            this.label44.Size = new System.Drawing.Size(35, 18);
            this.label44.TabIndex = 75;
            this.label44.Text = "Ke :";
            // 
            // comboBox12
            // 
            this.comboBox12.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox12.FormattingEnabled = true;
            this.comboBox12.Items.AddRange(new object[] {
            "Detik",
            "Menit",
            "Jam",
            "Hari",
            "Bulan",
            "Tahun"});
            this.comboBox12.Location = new System.Drawing.Point(156, 272);
            this.comboBox12.Name = "comboBox12";
            this.comboBox12.Size = new System.Drawing.Size(436, 30);
            this.comboBox12.TabIndex = 74;
            this.comboBox12.SelectedIndexChanged += new System.EventHandler(this.comboBox12_SelectedIndexChanged);
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label14.ForeColor = System.Drawing.Color.White;
            this.label14.Location = new System.Drawing.Point(75, 174);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(52, 18);
            this.label14.TabIndex = 73;
            this.label14.Text = "Input :";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label15.ForeColor = System.Drawing.Color.White;
            this.label15.Location = new System.Drawing.Point(70, 349);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(50, 18);
            this.label15.TabIndex = 72;
            this.label15.Text = "Hasil :";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.ForeColor = System.Drawing.Color.White;
            this.label32.Location = new System.Drawing.Point(76, 229);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(46, 18);
            this.label32.TabIndex = 70;
            this.label32.Text = "Dari :";
            // 
            // comboBox5
            // 
            this.comboBox5.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox5.FormattingEnabled = true;
            this.comboBox5.Items.AddRange(new object[] {
            "Detik",
            "Menit",
            "Jam",
            "Hari",
            "Bulan",
            "Tahun"});
            this.comboBox5.Location = new System.Drawing.Point(156, 223);
            this.comboBox5.Name = "comboBox5";
            this.comboBox5.Size = new System.Drawing.Size(436, 30);
            this.comboBox5.TabIndex = 49;
            this.comboBox5.SelectedIndexChanged += new System.EventHandler(this.comboBox5_SelectedIndexChanged);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.White;
            this.label7.Location = new System.Drawing.Point(221, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(221, 34);
            this.label7.TabIndex = 47;
            this.label7.Text = "Konversi Waktu";
            // 
            // bunifuTextBox5
            // 
            this.bunifuTextBox5.AcceptsReturn = false;
            this.bunifuTextBox5.AcceptsTab = false;
            this.bunifuTextBox5.AnimationSpeed = 200;
            this.bunifuTextBox5.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox5.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox5.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox5.BackgroundImage")));
            this.bunifuTextBox5.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.bunifuTextBox5.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuTextBox5.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuTextBox5.BorderColorIdle = System.Drawing.Color.Silver;
            this.bunifuTextBox5.BorderRadius = 1;
            this.bunifuTextBox5.BorderThickness = 1;
            this.bunifuTextBox5.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox5.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox5.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.bunifuTextBox5.DefaultText = "";
            this.bunifuTextBox5.FillColor = System.Drawing.Color.White;
            this.bunifuTextBox5.HideSelection = true;
            this.bunifuTextBox5.IconLeft = null;
            this.bunifuTextBox5.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox5.IconPadding = 10;
            this.bunifuTextBox5.IconRight = null;
            this.bunifuTextBox5.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox5.Lines = new string[0];
            this.bunifuTextBox5.Location = new System.Drawing.Point(153, 337);
            this.bunifuTextBox5.MaxLength = 32767;
            this.bunifuTextBox5.MinimumSize = new System.Drawing.Size(1, 1);
            this.bunifuTextBox5.Modified = false;
            this.bunifuTextBox5.Multiline = false;
            this.bunifuTextBox5.Name = "bunifuTextBox5";
            stateProperties49.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties49.FillColor = System.Drawing.Color.Empty;
            stateProperties49.ForeColor = System.Drawing.Color.Empty;
            stateProperties49.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox5.OnActiveState = stateProperties49;
            stateProperties50.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties50.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties50.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties50.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.bunifuTextBox5.OnDisabledState = stateProperties50;
            stateProperties51.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties51.FillColor = System.Drawing.Color.Empty;
            stateProperties51.ForeColor = System.Drawing.Color.Empty;
            stateProperties51.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox5.OnHoverState = stateProperties51;
            stateProperties52.BorderColor = System.Drawing.Color.Silver;
            stateProperties52.FillColor = System.Drawing.Color.White;
            stateProperties52.ForeColor = System.Drawing.Color.Empty;
            stateProperties52.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox5.OnIdleState = stateProperties52;
            this.bunifuTextBox5.Padding = new System.Windows.Forms.Padding(3);
            this.bunifuTextBox5.PasswordChar = '\0';
            this.bunifuTextBox5.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.bunifuTextBox5.PlaceholderText = "Enter text";
            this.bunifuTextBox5.ReadOnly = true;
            this.bunifuTextBox5.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.bunifuTextBox5.SelectedText = "";
            this.bunifuTextBox5.SelectionLength = 0;
            this.bunifuTextBox5.SelectionStart = 0;
            this.bunifuTextBox5.ShortcutsEnabled = true;
            this.bunifuTextBox5.Size = new System.Drawing.Size(439, 41);
            this.bunifuTextBox5.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox5.TabIndex = 52;
            this.bunifuTextBox5.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox5.TextMarginBottom = 0;
            this.bunifuTextBox5.TextMarginLeft = 3;
            this.bunifuTextBox5.TextMarginTop = 0;
            this.bunifuTextBox5.TextPlaceholder = "Enter text";
            this.bunifuTextBox5.UseSystemPasswordChar = false;
            this.bunifuTextBox5.WordWrap = true;
            this.bunifuTextBox5.TextChanged += new System.EventHandler(this.bunifuTextBox5_TextChanged);
            // 
            // bunifuTextBox3
            // 
            this.bunifuTextBox3.AcceptsReturn = false;
            this.bunifuTextBox3.AcceptsTab = false;
            this.bunifuTextBox3.AnimationSpeed = 200;
            this.bunifuTextBox3.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox3.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox3.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox3.BackgroundImage")));
            this.bunifuTextBox3.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.bunifuTextBox3.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuTextBox3.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuTextBox3.BorderColorIdle = System.Drawing.Color.Silver;
            this.bunifuTextBox3.BorderRadius = 1;
            this.bunifuTextBox3.BorderThickness = 1;
            this.bunifuTextBox3.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox3.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox3.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.bunifuTextBox3.DefaultText = "";
            this.bunifuTextBox3.FillColor = System.Drawing.Color.White;
            this.bunifuTextBox3.HideSelection = true;
            this.bunifuTextBox3.IconLeft = null;
            this.bunifuTextBox3.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox3.IconPadding = 10;
            this.bunifuTextBox3.IconRight = null;
            this.bunifuTextBox3.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox3.Lines = new string[0];
            this.bunifuTextBox3.Location = new System.Drawing.Point(156, 162);
            this.bunifuTextBox3.MaxLength = 32767;
            this.bunifuTextBox3.MinimumSize = new System.Drawing.Size(1, 1);
            this.bunifuTextBox3.Modified = false;
            this.bunifuTextBox3.Multiline = false;
            this.bunifuTextBox3.Name = "bunifuTextBox3";
            stateProperties53.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties53.FillColor = System.Drawing.Color.Empty;
            stateProperties53.ForeColor = System.Drawing.Color.Empty;
            stateProperties53.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox3.OnActiveState = stateProperties53;
            stateProperties54.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties54.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties54.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties54.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.bunifuTextBox3.OnDisabledState = stateProperties54;
            stateProperties55.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties55.FillColor = System.Drawing.Color.Empty;
            stateProperties55.ForeColor = System.Drawing.Color.Empty;
            stateProperties55.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox3.OnHoverState = stateProperties55;
            stateProperties56.BorderColor = System.Drawing.Color.Silver;
            stateProperties56.FillColor = System.Drawing.Color.White;
            stateProperties56.ForeColor = System.Drawing.Color.Empty;
            stateProperties56.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox3.OnIdleState = stateProperties56;
            this.bunifuTextBox3.Padding = new System.Windows.Forms.Padding(3);
            this.bunifuTextBox3.PasswordChar = '\0';
            this.bunifuTextBox3.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.bunifuTextBox3.PlaceholderText = "Enter text";
            this.bunifuTextBox3.ReadOnly = false;
            this.bunifuTextBox3.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.bunifuTextBox3.SelectedText = "";
            this.bunifuTextBox3.SelectionLength = 0;
            this.bunifuTextBox3.SelectionStart = 0;
            this.bunifuTextBox3.ShortcutsEnabled = true;
            this.bunifuTextBox3.Size = new System.Drawing.Size(435, 41);
            this.bunifuTextBox3.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox3.TabIndex = 48;
            this.bunifuTextBox3.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox3.TextMarginBottom = 0;
            this.bunifuTextBox3.TextMarginLeft = 3;
            this.bunifuTextBox3.TextMarginTop = 0;
            this.bunifuTextBox3.TextPlaceholder = "Enter text";
            this.bunifuTextBox3.UseSystemPasswordChar = false;
            this.bunifuTextBox3.WordWrap = true;
            this.bunifuTextBox3.TextChanged += new System.EventHandler(this.bunifuTextBox3_TextChanged);
            this.bunifuTextBox3.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.bunifuTextBox3_KeyPress);
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.tabPage5.Controls.Add(this.label38);
            this.tabPage5.Controls.Add(this.label19);
            this.tabPage5.Controls.Add(this.label34);
            this.tabPage5.Controls.Add(this.label6);
            this.tabPage5.Controls.Add(this.comboBox4);
            this.tabPage5.Controls.Add(this.comboBox3);
            this.tabPage5.Controls.Add(this.bunifuTextBox2);
            this.tabPage5.Location = new System.Drawing.Point(4, 4);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Size = new System.Drawing.Size(708, 585);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = " Volume";
            this.tabPage5.Click += new System.EventHandler(this.tabPage5_Click);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label38.ForeColor = System.Drawing.Color.White;
            this.label38.Location = new System.Drawing.Point(106, 306);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(35, 18);
            this.label38.TabIndex = 78;
            this.label38.Text = "Ke :";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label19.ForeColor = System.Drawing.Color.White;
            this.label19.Location = new System.Drawing.Point(106, 195);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(52, 18);
            this.label19.TabIndex = 76;
            this.label19.Text = "Input :";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label34.ForeColor = System.Drawing.Color.White;
            this.label34.Location = new System.Drawing.Point(107, 253);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(46, 18);
            this.label34.TabIndex = 74;
            this.label34.Text = "Dari :";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.ForeColor = System.Drawing.Color.White;
            this.label6.Location = new System.Drawing.Point(241, 13);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(243, 34);
            this.label6.TabIndex = 51;
            this.label6.Text = "Konversi Volume";
            // 
            // comboBox4
            // 
            this.comboBox4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox4.FormattingEnabled = true;
            this.comboBox4.Items.AddRange(new object[] {
            "Liter",
            "Milliliter",
            "Cubic Meter"});
            this.comboBox4.Location = new System.Drawing.Point(174, 300);
            this.comboBox4.Name = "comboBox4";
            this.comboBox4.Size = new System.Drawing.Size(404, 30);
            this.comboBox4.TabIndex = 45;
            this.comboBox4.SelectedIndexChanged += new System.EventHandler(this.comboBox4_SelectedIndexChanged);
            // 
            // comboBox3
            // 
            this.comboBox3.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Items.AddRange(new object[] {
            "Liter",
            "Milliliter",
            "Cubic Meter"});
            this.comboBox3.Location = new System.Drawing.Point(174, 249);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(403, 30);
            this.comboBox3.TabIndex = 44;
            // 
            // bunifuTextBox2
            // 
            this.bunifuTextBox2.AcceptsReturn = false;
            this.bunifuTextBox2.AcceptsTab = false;
            this.bunifuTextBox2.AnimationSpeed = 200;
            this.bunifuTextBox2.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox2.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox2.BackgroundImage")));
            this.bunifuTextBox2.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.bunifuTextBox2.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuTextBox2.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuTextBox2.BorderColorIdle = System.Drawing.Color.Silver;
            this.bunifuTextBox2.BorderRadius = 1;
            this.bunifuTextBox2.BorderThickness = 1;
            this.bunifuTextBox2.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox2.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox2.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.bunifuTextBox2.DefaultText = "";
            this.bunifuTextBox2.FillColor = System.Drawing.Color.White;
            this.bunifuTextBox2.HideSelection = true;
            this.bunifuTextBox2.IconLeft = null;
            this.bunifuTextBox2.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox2.IconPadding = 10;
            this.bunifuTextBox2.IconRight = null;
            this.bunifuTextBox2.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox2.Lines = new string[0];
            this.bunifuTextBox2.Location = new System.Drawing.Point(174, 183);
            this.bunifuTextBox2.MaxLength = 32767;
            this.bunifuTextBox2.MinimumSize = new System.Drawing.Size(1, 1);
            this.bunifuTextBox2.Modified = false;
            this.bunifuTextBox2.Multiline = false;
            this.bunifuTextBox2.Name = "bunifuTextBox2";
            stateProperties57.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties57.FillColor = System.Drawing.Color.Empty;
            stateProperties57.ForeColor = System.Drawing.Color.Empty;
            stateProperties57.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox2.OnActiveState = stateProperties57;
            stateProperties58.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties58.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties58.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties58.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.bunifuTextBox2.OnDisabledState = stateProperties58;
            stateProperties59.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties59.FillColor = System.Drawing.Color.Empty;
            stateProperties59.ForeColor = System.Drawing.Color.Empty;
            stateProperties59.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox2.OnHoverState = stateProperties59;
            stateProperties60.BorderColor = System.Drawing.Color.Silver;
            stateProperties60.FillColor = System.Drawing.Color.White;
            stateProperties60.ForeColor = System.Drawing.Color.Empty;
            stateProperties60.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox2.OnIdleState = stateProperties60;
            this.bunifuTextBox2.Padding = new System.Windows.Forms.Padding(3);
            this.bunifuTextBox2.PasswordChar = '\0';
            this.bunifuTextBox2.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.bunifuTextBox2.PlaceholderText = "Enter text";
            this.bunifuTextBox2.ReadOnly = false;
            this.bunifuTextBox2.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.bunifuTextBox2.SelectedText = "";
            this.bunifuTextBox2.SelectionLength = 0;
            this.bunifuTextBox2.SelectionStart = 0;
            this.bunifuTextBox2.ShortcutsEnabled = true;
            this.bunifuTextBox2.Size = new System.Drawing.Size(403, 41);
            this.bunifuTextBox2.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox2.TabIndex = 43;
            this.bunifuTextBox2.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox2.TextMarginBottom = 0;
            this.bunifuTextBox2.TextMarginLeft = 3;
            this.bunifuTextBox2.TextMarginTop = 0;
            this.bunifuTextBox2.TextPlaceholder = "Enter text";
            this.bunifuTextBox2.UseSystemPasswordChar = false;
            this.bunifuTextBox2.WordWrap = true;
            this.bunifuTextBox2.TextChanged += new System.EventHandler(this.bunifuTextBox2_TextChanged);
            this.bunifuTextBox2.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.bunifuTextBox2_KeyPress);
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.tabPage6.Controls.Add(this.label39);
            this.tabPage6.Controls.Add(this.label40);
            this.tabPage6.Controls.Add(this.comboBox9);
            this.tabPage6.Controls.Add(this.label22);
            this.tabPage6.Controls.Add(this.label21);
            this.tabPage6.Controls.Add(this.bunifuTextBox7);
            this.tabPage6.Controls.Add(this.comboBox8);
            this.tabPage6.Controls.Add(this.bunifuTextBox6);
            this.tabPage6.Controls.Add(this.label20);
            this.tabPage6.Location = new System.Drawing.Point(4, 4);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Size = new System.Drawing.Size(708, 585);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Area";
            this.tabPage6.Click += new System.EventHandler(this.tabPage6_Click);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label39.ForeColor = System.Drawing.Color.White;
            this.label39.Location = new System.Drawing.Point(131, 281);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(35, 18);
            this.label39.TabIndex = 80;
            this.label39.Text = "Ke :";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label40.ForeColor = System.Drawing.Color.White;
            this.label40.Location = new System.Drawing.Point(123, 236);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(46, 18);
            this.label40.TabIndex = 79;
            this.label40.Text = "Dari :";
            // 
            // comboBox9
            // 
            this.comboBox9.FormattingEnabled = true;
            this.comboBox9.Items.AddRange(new object[] {
            "Meter Persegi",
            "Kilometer Persegi",
            "Hektar",
            "Acre"});
            this.comboBox9.Location = new System.Drawing.Point(184, 276);
            this.comboBox9.Name = "comboBox9";
            this.comboBox9.Size = new System.Drawing.Size(413, 24);
            this.comboBox9.TabIndex = 60;
            this.comboBox9.SelectedIndexChanged += new System.EventHandler(this.comboBox9_SelectedIndexChanged);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.BackColor = System.Drawing.Color.Transparent;
            this.label22.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label22.ForeColor = System.Drawing.Color.White;
            this.label22.Location = new System.Drawing.Point(111, 329);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(58, 19);
            this.label22.TabIndex = 59;
            this.label22.Text = "Hasil :";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.BackColor = System.Drawing.Color.Transparent;
            this.label21.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label21.ForeColor = System.Drawing.Color.White;
            this.label21.Location = new System.Drawing.Point(112, 186);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(64, 19);
            this.label21.TabIndex = 58;
            this.label21.Text = "Input : ";
            // 
            // bunifuTextBox7
            // 
            this.bunifuTextBox7.AcceptsReturn = false;
            this.bunifuTextBox7.AcceptsTab = false;
            this.bunifuTextBox7.AnimationSpeed = 200;
            this.bunifuTextBox7.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox7.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox7.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox7.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox7.BackgroundImage")));
            this.bunifuTextBox7.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.bunifuTextBox7.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuTextBox7.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuTextBox7.BorderColorIdle = System.Drawing.Color.Silver;
            this.bunifuTextBox7.BorderRadius = 1;
            this.bunifuTextBox7.BorderThickness = 1;
            this.bunifuTextBox7.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox7.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox7.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.bunifuTextBox7.DefaultText = "";
            this.bunifuTextBox7.FillColor = System.Drawing.Color.White;
            this.bunifuTextBox7.HideSelection = true;
            this.bunifuTextBox7.IconLeft = null;
            this.bunifuTextBox7.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox7.IconPadding = 10;
            this.bunifuTextBox7.IconRight = null;
            this.bunifuTextBox7.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox7.Lines = new string[0];
            this.bunifuTextBox7.Location = new System.Drawing.Point(184, 321);
            this.bunifuTextBox7.MaxLength = 32767;
            this.bunifuTextBox7.MinimumSize = new System.Drawing.Size(1, 1);
            this.bunifuTextBox7.Modified = false;
            this.bunifuTextBox7.Multiline = false;
            this.bunifuTextBox7.Name = "bunifuTextBox7";
            stateProperties61.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties61.FillColor = System.Drawing.Color.Empty;
            stateProperties61.ForeColor = System.Drawing.Color.Empty;
            stateProperties61.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox7.OnActiveState = stateProperties61;
            stateProperties62.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties62.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties62.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties62.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.bunifuTextBox7.OnDisabledState = stateProperties62;
            stateProperties63.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties63.FillColor = System.Drawing.Color.Empty;
            stateProperties63.ForeColor = System.Drawing.Color.Empty;
            stateProperties63.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox7.OnHoverState = stateProperties63;
            stateProperties64.BorderColor = System.Drawing.Color.Silver;
            stateProperties64.FillColor = System.Drawing.Color.White;
            stateProperties64.ForeColor = System.Drawing.Color.Empty;
            stateProperties64.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox7.OnIdleState = stateProperties64;
            this.bunifuTextBox7.Padding = new System.Windows.Forms.Padding(3);
            this.bunifuTextBox7.PasswordChar = '\0';
            this.bunifuTextBox7.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.bunifuTextBox7.PlaceholderText = "Enter text";
            this.bunifuTextBox7.ReadOnly = true;
            this.bunifuTextBox7.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.bunifuTextBox7.SelectedText = "";
            this.bunifuTextBox7.SelectionLength = 0;
            this.bunifuTextBox7.SelectionStart = 0;
            this.bunifuTextBox7.ShortcutsEnabled = true;
            this.bunifuTextBox7.Size = new System.Drawing.Size(413, 39);
            this.bunifuTextBox7.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox7.TabIndex = 57;
            this.bunifuTextBox7.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox7.TextMarginBottom = 0;
            this.bunifuTextBox7.TextMarginLeft = 3;
            this.bunifuTextBox7.TextMarginTop = 0;
            this.bunifuTextBox7.TextPlaceholder = "Enter text";
            this.bunifuTextBox7.UseSystemPasswordChar = false;
            this.bunifuTextBox7.WordWrap = true;
            // 
            // comboBox8
            // 
            this.comboBox8.FormattingEnabled = true;
            this.comboBox8.Items.AddRange(new object[] {
            "Meter Persegi",
            "Kilometer Persegi",
            "Hektar",
            "Acre"});
            this.comboBox8.Location = new System.Drawing.Point(184, 236);
            this.comboBox8.Name = "comboBox8";
            this.comboBox8.Size = new System.Drawing.Size(413, 24);
            this.comboBox8.TabIndex = 55;
            // 
            // bunifuTextBox6
            // 
            this.bunifuTextBox6.AcceptsReturn = false;
            this.bunifuTextBox6.AcceptsTab = false;
            this.bunifuTextBox6.AnimationSpeed = 200;
            this.bunifuTextBox6.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox6.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox6.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox6.BackgroundImage")));
            this.bunifuTextBox6.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.bunifuTextBox6.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuTextBox6.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuTextBox6.BorderColorIdle = System.Drawing.Color.Silver;
            this.bunifuTextBox6.BorderRadius = 1;
            this.bunifuTextBox6.BorderThickness = 1;
            this.bunifuTextBox6.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox6.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox6.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.bunifuTextBox6.DefaultText = "";
            this.bunifuTextBox6.FillColor = System.Drawing.Color.White;
            this.bunifuTextBox6.HideSelection = true;
            this.bunifuTextBox6.IconLeft = null;
            this.bunifuTextBox6.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox6.IconPadding = 10;
            this.bunifuTextBox6.IconRight = null;
            this.bunifuTextBox6.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox6.Lines = new string[0];
            this.bunifuTextBox6.Location = new System.Drawing.Point(184, 181);
            this.bunifuTextBox6.MaxLength = 32767;
            this.bunifuTextBox6.MinimumSize = new System.Drawing.Size(1, 1);
            this.bunifuTextBox6.Modified = false;
            this.bunifuTextBox6.Multiline = false;
            this.bunifuTextBox6.Name = "bunifuTextBox6";
            stateProperties65.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties65.FillColor = System.Drawing.Color.Empty;
            stateProperties65.ForeColor = System.Drawing.Color.Empty;
            stateProperties65.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox6.OnActiveState = stateProperties65;
            stateProperties66.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties66.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties66.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties66.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.bunifuTextBox6.OnDisabledState = stateProperties66;
            stateProperties67.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties67.FillColor = System.Drawing.Color.Empty;
            stateProperties67.ForeColor = System.Drawing.Color.Empty;
            stateProperties67.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox6.OnHoverState = stateProperties67;
            stateProperties68.BorderColor = System.Drawing.Color.Silver;
            stateProperties68.FillColor = System.Drawing.Color.White;
            stateProperties68.ForeColor = System.Drawing.Color.Empty;
            stateProperties68.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox6.OnIdleState = stateProperties68;
            this.bunifuTextBox6.Padding = new System.Windows.Forms.Padding(3);
            this.bunifuTextBox6.PasswordChar = '\0';
            this.bunifuTextBox6.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.bunifuTextBox6.PlaceholderText = "Enter text";
            this.bunifuTextBox6.ReadOnly = false;
            this.bunifuTextBox6.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.bunifuTextBox6.SelectedText = "";
            this.bunifuTextBox6.SelectionLength = 0;
            this.bunifuTextBox6.SelectionStart = 0;
            this.bunifuTextBox6.ShortcutsEnabled = true;
            this.bunifuTextBox6.Size = new System.Drawing.Size(413, 39);
            this.bunifuTextBox6.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox6.TabIndex = 53;
            this.bunifuTextBox6.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox6.TextMarginBottom = 0;
            this.bunifuTextBox6.TextMarginLeft = 3;
            this.bunifuTextBox6.TextMarginTop = 0;
            this.bunifuTextBox6.TextPlaceholder = "Enter text";
            this.bunifuTextBox6.UseSystemPasswordChar = false;
            this.bunifuTextBox6.WordWrap = true;
            this.bunifuTextBox6.TextChanged += new System.EventHandler(this.bunifuTextBox6_TextChanged);
            this.bunifuTextBox6.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.bunifuTextBox6_KeyPress);
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label20.ForeColor = System.Drawing.Color.White;
            this.label20.Location = new System.Drawing.Point(254, 22);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(203, 34);
            this.label20.TabIndex = 52;
            this.label20.Text = "Konversi Area";
            // 
            // tabPage7
            // 
            this.tabPage7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.tabPage7.Controls.Add(this.label27);
            this.tabPage7.Controls.Add(this.label35);
            this.tabPage7.Controls.Add(this.label36);
            this.tabPage7.Controls.Add(this.label37);
            this.tabPage7.Controls.Add(this.comboBox11);
            this.tabPage7.Controls.Add(this.comboBox10);
            this.tabPage7.Controls.Add(this.bunifuTextBox9);
            this.tabPage7.Controls.Add(this.bunifuTextBox8);
            this.tabPage7.Controls.Add(this.label26);
            this.tabPage7.Location = new System.Drawing.Point(4, 4);
            this.tabPage7.Name = "tabPage7";
            this.tabPage7.Size = new System.Drawing.Size(708, 585);
            this.tabPage7.TabIndex = 6;
            this.tabPage7.Text = "Data";
            this.tabPage7.Click += new System.EventHandler(this.tabPage7_Click);
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label27.ForeColor = System.Drawing.Color.White;
            this.label27.Location = new System.Drawing.Point(99, 165);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(52, 18);
            this.label27.TabIndex = 77;
            this.label27.Text = "Input :";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label35.ForeColor = System.Drawing.Color.White;
            this.label35.Location = new System.Drawing.Point(97, 340);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(50, 18);
            this.label35.TabIndex = 76;
            this.label35.Text = "Hasil :";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label36.ForeColor = System.Drawing.Color.White;
            this.label36.Location = new System.Drawing.Point(105, 269);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(35, 18);
            this.label36.TabIndex = 75;
            this.label36.Text = "Ke :";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label37.ForeColor = System.Drawing.Color.White;
            this.label37.Location = new System.Drawing.Point(93, 220);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(46, 18);
            this.label37.TabIndex = 74;
            this.label37.Text = "Dari :";
            // 
            // comboBox11
            // 
            this.comboBox11.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox11.FormattingEnabled = true;
            this.comboBox11.Items.AddRange(new object[] {
            "TB (terabyte)",
            "GB (gigabyte) ",
            "MB (megabyte)",
            "KB (kilobyte)"});
            this.comboBox11.Location = new System.Drawing.Point(171, 263);
            this.comboBox11.Name = "comboBox11";
            this.comboBox11.Size = new System.Drawing.Size(408, 37);
            this.comboBox11.TabIndex = 73;
            this.comboBox11.SelectedIndexChanged += new System.EventHandler(this.comboBox11_SelectedIndexChanged);
            // 
            // comboBox10
            // 
            this.comboBox10.Font = new System.Drawing.Font("Microsoft Sans Serif", 13.8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.comboBox10.FormattingEnabled = true;
            this.comboBox10.Items.AddRange(new object[] {
            "TB (terabyte)",
            "GB (gigabyte) ",
            "MB (megabyte)",
            "KB (kilobyte)"});
            this.comboBox10.Location = new System.Drawing.Point(171, 213);
            this.comboBox10.Name = "comboBox10";
            this.comboBox10.Size = new System.Drawing.Size(408, 37);
            this.comboBox10.TabIndex = 72;
            this.comboBox10.SelectedIndexChanged += new System.EventHandler(this.comboBox10_SelectedIndexChanged);
            // 
            // bunifuTextBox9
            // 
            this.bunifuTextBox9.AcceptsReturn = false;
            this.bunifuTextBox9.AcceptsTab = false;
            this.bunifuTextBox9.AnimationSpeed = 200;
            this.bunifuTextBox9.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox9.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox9.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox9.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox9.BackgroundImage")));
            this.bunifuTextBox9.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.bunifuTextBox9.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuTextBox9.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuTextBox9.BorderColorIdle = System.Drawing.Color.Silver;
            this.bunifuTextBox9.BorderRadius = 1;
            this.bunifuTextBox9.BorderThickness = 1;
            this.bunifuTextBox9.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox9.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox9.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.bunifuTextBox9.DefaultText = "";
            this.bunifuTextBox9.FillColor = System.Drawing.Color.White;
            this.bunifuTextBox9.HideSelection = true;
            this.bunifuTextBox9.IconLeft = null;
            this.bunifuTextBox9.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox9.IconPadding = 10;
            this.bunifuTextBox9.IconRight = null;
            this.bunifuTextBox9.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox9.Lines = new string[0];
            this.bunifuTextBox9.Location = new System.Drawing.Point(171, 330);
            this.bunifuTextBox9.MaxLength = 32767;
            this.bunifuTextBox9.MinimumSize = new System.Drawing.Size(1, 1);
            this.bunifuTextBox9.Modified = false;
            this.bunifuTextBox9.Multiline = false;
            this.bunifuTextBox9.Name = "bunifuTextBox9";
            stateProperties69.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties69.FillColor = System.Drawing.Color.Empty;
            stateProperties69.ForeColor = System.Drawing.Color.Empty;
            stateProperties69.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox9.OnActiveState = stateProperties69;
            stateProperties70.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties70.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties70.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties70.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.bunifuTextBox9.OnDisabledState = stateProperties70;
            stateProperties71.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties71.FillColor = System.Drawing.Color.Empty;
            stateProperties71.ForeColor = System.Drawing.Color.Empty;
            stateProperties71.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox9.OnHoverState = stateProperties71;
            stateProperties72.BorderColor = System.Drawing.Color.Silver;
            stateProperties72.FillColor = System.Drawing.Color.White;
            stateProperties72.ForeColor = System.Drawing.Color.Empty;
            stateProperties72.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox9.OnIdleState = stateProperties72;
            this.bunifuTextBox9.Padding = new System.Windows.Forms.Padding(3);
            this.bunifuTextBox9.PasswordChar = '\0';
            this.bunifuTextBox9.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.bunifuTextBox9.PlaceholderText = "Enter text";
            this.bunifuTextBox9.ReadOnly = false;
            this.bunifuTextBox9.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.bunifuTextBox9.SelectedText = "";
            this.bunifuTextBox9.SelectionLength = 0;
            this.bunifuTextBox9.SelectionStart = 0;
            this.bunifuTextBox9.ShortcutsEnabled = true;
            this.bunifuTextBox9.Size = new System.Drawing.Size(408, 41);
            this.bunifuTextBox9.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox9.TabIndex = 71;
            this.bunifuTextBox9.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox9.TextMarginBottom = 0;
            this.bunifuTextBox9.TextMarginLeft = 3;
            this.bunifuTextBox9.TextMarginTop = 0;
            this.bunifuTextBox9.TextPlaceholder = "Enter text";
            this.bunifuTextBox9.UseSystemPasswordChar = false;
            this.bunifuTextBox9.WordWrap = true;
            // 
            // bunifuTextBox8
            // 
            this.bunifuTextBox8.AcceptsReturn = false;
            this.bunifuTextBox8.AcceptsTab = false;
            this.bunifuTextBox8.AnimationSpeed = 200;
            this.bunifuTextBox8.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.bunifuTextBox8.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.bunifuTextBox8.BackColor = System.Drawing.Color.Transparent;
            this.bunifuTextBox8.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("bunifuTextBox8.BackgroundImage")));
            this.bunifuTextBox8.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.bunifuTextBox8.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.bunifuTextBox8.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.bunifuTextBox8.BorderColorIdle = System.Drawing.Color.Silver;
            this.bunifuTextBox8.BorderRadius = 1;
            this.bunifuTextBox8.BorderThickness = 1;
            this.bunifuTextBox8.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.bunifuTextBox8.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox8.DefaultFont = new System.Drawing.Font("Segoe UI", 9.25F);
            this.bunifuTextBox8.DefaultText = "";
            this.bunifuTextBox8.FillColor = System.Drawing.Color.White;
            this.bunifuTextBox8.HideSelection = true;
            this.bunifuTextBox8.IconLeft = null;
            this.bunifuTextBox8.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox8.IconPadding = 10;
            this.bunifuTextBox8.IconRight = null;
            this.bunifuTextBox8.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.bunifuTextBox8.Lines = new string[0];
            this.bunifuTextBox8.Location = new System.Drawing.Point(171, 155);
            this.bunifuTextBox8.MaxLength = 32767;
            this.bunifuTextBox8.MinimumSize = new System.Drawing.Size(1, 1);
            this.bunifuTextBox8.Modified = false;
            this.bunifuTextBox8.Multiline = false;
            this.bunifuTextBox8.Name = "bunifuTextBox8";
            stateProperties73.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties73.FillColor = System.Drawing.Color.Empty;
            stateProperties73.ForeColor = System.Drawing.Color.Empty;
            stateProperties73.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox8.OnActiveState = stateProperties73;
            stateProperties74.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties74.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties74.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties74.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.bunifuTextBox8.OnDisabledState = stateProperties74;
            stateProperties75.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties75.FillColor = System.Drawing.Color.Empty;
            stateProperties75.ForeColor = System.Drawing.Color.Empty;
            stateProperties75.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox8.OnHoverState = stateProperties75;
            stateProperties76.BorderColor = System.Drawing.Color.Silver;
            stateProperties76.FillColor = System.Drawing.Color.White;
            stateProperties76.ForeColor = System.Drawing.Color.Empty;
            stateProperties76.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.bunifuTextBox8.OnIdleState = stateProperties76;
            this.bunifuTextBox8.Padding = new System.Windows.Forms.Padding(3);
            this.bunifuTextBox8.PasswordChar = '\0';
            this.bunifuTextBox8.PlaceholderForeColor = System.Drawing.Color.Silver;
            this.bunifuTextBox8.PlaceholderText = "Enter text";
            this.bunifuTextBox8.ReadOnly = false;
            this.bunifuTextBox8.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.bunifuTextBox8.SelectedText = "";
            this.bunifuTextBox8.SelectionLength = 0;
            this.bunifuTextBox8.SelectionStart = 0;
            this.bunifuTextBox8.ShortcutsEnabled = true;
            this.bunifuTextBox8.Size = new System.Drawing.Size(408, 41);
            this.bunifuTextBox8.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.bunifuTextBox8.TabIndex = 65;
            this.bunifuTextBox8.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.bunifuTextBox8.TextMarginBottom = 0;
            this.bunifuTextBox8.TextMarginLeft = 3;
            this.bunifuTextBox8.TextMarginTop = 0;
            this.bunifuTextBox8.TextPlaceholder = "Enter text";
            this.bunifuTextBox8.UseSystemPasswordChar = false;
            this.bunifuTextBox8.WordWrap = true;
            this.bunifuTextBox8.TextChanged += new System.EventHandler(this.bunifuTextBox8_TextChanged);
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Font = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label26.ForeColor = System.Drawing.Color.White;
            this.label26.Location = new System.Drawing.Point(240, 11);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(201, 34);
            this.label26.TabIndex = 64;
            this.label26.Text = "Konversi Data";
            // 
            // tabPage8
            // 
            this.tabPage8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.tabPage8.Controls.Add(this.PercentBtn);
            this.tabPage8.Controls.Add(this.PlusminusBtn);
            this.tabPage8.Controls.Add(this.MultipleBtn);
            this.tabPage8.Controls.Add(this.PlusBtn);
            this.tabPage8.Controls.Add(this.DivideBtn);
            this.tabPage8.Controls.Add(this.MinusBtn);
            this.tabPage8.Controls.Add(this.ClearBtn);
            this.tabPage8.Controls.Add(this.EqualBtn);
            this.tabPage8.Controls.Add(this.DotBtn);
            this.tabPage8.Controls.Add(this.ZeroBtn);
            this.tabPage8.Controls.Add(this.SixBtn);
            this.tabPage8.Controls.Add(this.OneBtn);
            this.tabPage8.Controls.Add(this.TwoBtn);
            this.tabPage8.Controls.Add(this.ThreeBtn);
            this.tabPage8.Controls.Add(this.FourBtn);
            this.tabPage8.Controls.Add(this.FiveBtn);
            this.tabPage8.Controls.Add(this.NineBtn);
            this.tabPage8.Controls.Add(this.EightBtn);
            this.tabPage8.Controls.Add(this.SevenBtn);
            this.tabPage8.Controls.Add(this.TxtBox);
            this.tabPage8.Location = new System.Drawing.Point(4, 4);
            this.tabPage8.Name = "tabPage8";
            this.tabPage8.Size = new System.Drawing.Size(708, 585);
            this.tabPage8.TabIndex = 7;
            this.tabPage8.Text = "Kalkulator";
            this.tabPage8.Click += new System.EventHandler(this.tabPage8_Click);
            // 
            // PercentBtn
            // 
            this.PercentBtn.AllowAnimations = true;
            this.PercentBtn.AllowMouseEffects = true;
            this.PercentBtn.AllowToggling = false;
            this.PercentBtn.AnimationSpeed = 200;
            this.PercentBtn.AutoGenerateColors = false;
            this.PercentBtn.AutoRoundBorders = false;
            this.PercentBtn.AutoSizeLeftIcon = true;
            this.PercentBtn.AutoSizeRightIcon = true;
            this.PercentBtn.BackColor = System.Drawing.Color.Transparent;
            this.PercentBtn.BackColor1 = System.Drawing.Color.Yellow;
            this.PercentBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PercentBtn.BackgroundImage")));
            this.PercentBtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.PercentBtn.ButtonText = "%";
            this.PercentBtn.ButtonTextMarginLeft = 0;
            this.PercentBtn.ColorContrastOnClick = 45;
            this.PercentBtn.ColorContrastOnHover = 45;
            this.PercentBtn.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges20.BottomLeft = true;
            borderEdges20.BottomRight = true;
            borderEdges20.TopLeft = true;
            borderEdges20.TopRight = true;
            this.PercentBtn.CustomizableEdges = borderEdges20;
            this.PercentBtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.PercentBtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.PercentBtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.PercentBtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.PercentBtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.PercentBtn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PercentBtn.ForeColor = System.Drawing.Color.Black;
            this.PercentBtn.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.PercentBtn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.PercentBtn.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.PercentBtn.IconMarginLeft = 11;
            this.PercentBtn.IconPadding = 10;
            this.PercentBtn.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.PercentBtn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.PercentBtn.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.PercentBtn.IconSize = 25;
            this.PercentBtn.IdleBorderColor = System.Drawing.Color.White;
            this.PercentBtn.IdleBorderRadius = 1;
            this.PercentBtn.IdleBorderThickness = 1;
            this.PercentBtn.IdleFillColor = System.Drawing.Color.Yellow;
            this.PercentBtn.IdleIconLeftImage = null;
            this.PercentBtn.IdleIconRightImage = null;
            this.PercentBtn.IndicateFocus = false;
            this.PercentBtn.Location = new System.Drawing.Point(597, 482);
            this.PercentBtn.Name = "PercentBtn";
            this.PercentBtn.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.PercentBtn.OnDisabledState.BorderRadius = 1;
            this.PercentBtn.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.PercentBtn.OnDisabledState.BorderThickness = 1;
            this.PercentBtn.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.PercentBtn.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.PercentBtn.OnDisabledState.IconLeftImage = null;
            this.PercentBtn.OnDisabledState.IconRightImage = null;
            this.PercentBtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.PercentBtn.onHoverState.BorderRadius = 1;
            this.PercentBtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.PercentBtn.onHoverState.BorderThickness = 1;
            this.PercentBtn.onHoverState.FillColor = System.Drawing.Color.Gold;
            this.PercentBtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.PercentBtn.onHoverState.IconLeftImage = null;
            this.PercentBtn.onHoverState.IconRightImage = null;
            this.PercentBtn.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.PercentBtn.OnIdleState.BorderRadius = 1;
            this.PercentBtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.PercentBtn.OnIdleState.BorderThickness = 1;
            this.PercentBtn.OnIdleState.FillColor = System.Drawing.Color.Yellow;
            this.PercentBtn.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.PercentBtn.OnIdleState.IconLeftImage = null;
            this.PercentBtn.OnIdleState.IconRightImage = null;
            this.PercentBtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.PercentBtn.OnPressedState.BorderRadius = 1;
            this.PercentBtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.PercentBtn.OnPressedState.BorderThickness = 1;
            this.PercentBtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.PercentBtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.PercentBtn.OnPressedState.IconLeftImage = null;
            this.PercentBtn.OnPressedState.IconRightImage = null;
            this.PercentBtn.Size = new System.Drawing.Size(75, 75);
            this.PercentBtn.TabIndex = 20;
            this.PercentBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.PercentBtn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.PercentBtn.TextMarginLeft = 0;
            this.PercentBtn.TextPadding = new System.Windows.Forms.Padding(0);
            this.PercentBtn.UseDefaultRadiusAndThickness = true;
            this.PercentBtn.Click += new System.EventHandler(this.PercentBtn_Click);
            // 
            // PlusminusBtn
            // 
            this.PlusminusBtn.AllowAnimations = true;
            this.PlusminusBtn.AllowMouseEffects = true;
            this.PlusminusBtn.AllowToggling = false;
            this.PlusminusBtn.AnimationSpeed = 200;
            this.PlusminusBtn.AutoGenerateColors = false;
            this.PlusminusBtn.AutoRoundBorders = false;
            this.PlusminusBtn.AutoSizeLeftIcon = true;
            this.PlusminusBtn.AutoSizeRightIcon = true;
            this.PlusminusBtn.BackColor = System.Drawing.Color.Transparent;
            this.PlusminusBtn.BackColor1 = System.Drawing.Color.Yellow;
            this.PlusminusBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PlusminusBtn.BackgroundImage")));
            this.PlusminusBtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.PlusminusBtn.ButtonText = "-/+";
            this.PlusminusBtn.ButtonTextMarginLeft = 0;
            this.PlusminusBtn.ColorContrastOnClick = 45;
            this.PlusminusBtn.ColorContrastOnHover = 45;
            this.PlusminusBtn.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges21.BottomLeft = true;
            borderEdges21.BottomRight = true;
            borderEdges21.TopLeft = true;
            borderEdges21.TopRight = true;
            this.PlusminusBtn.CustomizableEdges = borderEdges21;
            this.PlusminusBtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.PlusminusBtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.PlusminusBtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.PlusminusBtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.PlusminusBtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.PlusminusBtn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PlusminusBtn.ForeColor = System.Drawing.Color.Black;
            this.PlusminusBtn.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.PlusminusBtn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.PlusminusBtn.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.PlusminusBtn.IconMarginLeft = 11;
            this.PlusminusBtn.IconPadding = 10;
            this.PlusminusBtn.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.PlusminusBtn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.PlusminusBtn.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.PlusminusBtn.IconSize = 25;
            this.PlusminusBtn.IdleBorderColor = System.Drawing.Color.White;
            this.PlusminusBtn.IdleBorderRadius = 1;
            this.PlusminusBtn.IdleBorderThickness = 1;
            this.PlusminusBtn.IdleFillColor = System.Drawing.Color.Yellow;
            this.PlusminusBtn.IdleIconLeftImage = null;
            this.PlusminusBtn.IdleIconRightImage = null;
            this.PlusminusBtn.IndicateFocus = false;
            this.PlusminusBtn.Location = new System.Drawing.Point(481, 482);
            this.PlusminusBtn.Name = "PlusminusBtn";
            this.PlusminusBtn.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.PlusminusBtn.OnDisabledState.BorderRadius = 1;
            this.PlusminusBtn.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.PlusminusBtn.OnDisabledState.BorderThickness = 1;
            this.PlusminusBtn.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.PlusminusBtn.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.PlusminusBtn.OnDisabledState.IconLeftImage = null;
            this.PlusminusBtn.OnDisabledState.IconRightImage = null;
            this.PlusminusBtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.PlusminusBtn.onHoverState.BorderRadius = 1;
            this.PlusminusBtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.PlusminusBtn.onHoverState.BorderThickness = 1;
            this.PlusminusBtn.onHoverState.FillColor = System.Drawing.Color.Gold;
            this.PlusminusBtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.PlusminusBtn.onHoverState.IconLeftImage = null;
            this.PlusminusBtn.onHoverState.IconRightImage = null;
            this.PlusminusBtn.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.PlusminusBtn.OnIdleState.BorderRadius = 1;
            this.PlusminusBtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.PlusminusBtn.OnIdleState.BorderThickness = 1;
            this.PlusminusBtn.OnIdleState.FillColor = System.Drawing.Color.Yellow;
            this.PlusminusBtn.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.PlusminusBtn.OnIdleState.IconLeftImage = null;
            this.PlusminusBtn.OnIdleState.IconRightImage = null;
            this.PlusminusBtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.PlusminusBtn.OnPressedState.BorderRadius = 1;
            this.PlusminusBtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.PlusminusBtn.OnPressedState.BorderThickness = 1;
            this.PlusminusBtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.PlusminusBtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.PlusminusBtn.OnPressedState.IconLeftImage = null;
            this.PlusminusBtn.OnPressedState.IconRightImage = null;
            this.PlusminusBtn.Size = new System.Drawing.Size(75, 75);
            this.PlusminusBtn.TabIndex = 19;
            this.PlusminusBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.PlusminusBtn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.PlusminusBtn.TextMarginLeft = 0;
            this.PlusminusBtn.TextPadding = new System.Windows.Forms.Padding(0);
            this.PlusminusBtn.UseDefaultRadiusAndThickness = true;
            this.PlusminusBtn.Click += new System.EventHandler(this.PlusminusBtn_Click);
            // 
            // MultipleBtn
            // 
            this.MultipleBtn.AllowAnimations = true;
            this.MultipleBtn.AllowMouseEffects = true;
            this.MultipleBtn.AllowToggling = false;
            this.MultipleBtn.AnimationSpeed = 200;
            this.MultipleBtn.AutoGenerateColors = false;
            this.MultipleBtn.AutoRoundBorders = false;
            this.MultipleBtn.AutoSizeLeftIcon = true;
            this.MultipleBtn.AutoSizeRightIcon = true;
            this.MultipleBtn.BackColor = System.Drawing.Color.Transparent;
            this.MultipleBtn.BackColor1 = System.Drawing.Color.Yellow;
            this.MultipleBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("MultipleBtn.BackgroundImage")));
            this.MultipleBtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.MultipleBtn.ButtonText = "X";
            this.MultipleBtn.ButtonTextMarginLeft = 0;
            this.MultipleBtn.ColorContrastOnClick = 45;
            this.MultipleBtn.ColorContrastOnHover = 45;
            this.MultipleBtn.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges22.BottomLeft = true;
            borderEdges22.BottomRight = true;
            borderEdges22.TopLeft = true;
            borderEdges22.TopRight = true;
            this.MultipleBtn.CustomizableEdges = borderEdges22;
            this.MultipleBtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.MultipleBtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.MultipleBtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.MultipleBtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.MultipleBtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.MultipleBtn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MultipleBtn.ForeColor = System.Drawing.Color.Black;
            this.MultipleBtn.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.MultipleBtn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.MultipleBtn.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.MultipleBtn.IconMarginLeft = 11;
            this.MultipleBtn.IconPadding = 10;
            this.MultipleBtn.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.MultipleBtn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.MultipleBtn.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.MultipleBtn.IconSize = 25;
            this.MultipleBtn.IdleBorderColor = System.Drawing.Color.White;
            this.MultipleBtn.IdleBorderRadius = 1;
            this.MultipleBtn.IdleBorderThickness = 1;
            this.MultipleBtn.IdleFillColor = System.Drawing.Color.Yellow;
            this.MultipleBtn.IdleIconLeftImage = null;
            this.MultipleBtn.IdleIconRightImage = null;
            this.MultipleBtn.IndicateFocus = false;
            this.MultipleBtn.Location = new System.Drawing.Point(597, 375);
            this.MultipleBtn.Name = "MultipleBtn";
            this.MultipleBtn.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.MultipleBtn.OnDisabledState.BorderRadius = 1;
            this.MultipleBtn.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.MultipleBtn.OnDisabledState.BorderThickness = 1;
            this.MultipleBtn.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.MultipleBtn.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.MultipleBtn.OnDisabledState.IconLeftImage = null;
            this.MultipleBtn.OnDisabledState.IconRightImage = null;
            this.MultipleBtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.MultipleBtn.onHoverState.BorderRadius = 1;
            this.MultipleBtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.MultipleBtn.onHoverState.BorderThickness = 1;
            this.MultipleBtn.onHoverState.FillColor = System.Drawing.Color.Gold;
            this.MultipleBtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.MultipleBtn.onHoverState.IconLeftImage = null;
            this.MultipleBtn.onHoverState.IconRightImage = null;
            this.MultipleBtn.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.MultipleBtn.OnIdleState.BorderRadius = 1;
            this.MultipleBtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.MultipleBtn.OnIdleState.BorderThickness = 1;
            this.MultipleBtn.OnIdleState.FillColor = System.Drawing.Color.Yellow;
            this.MultipleBtn.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.MultipleBtn.OnIdleState.IconLeftImage = null;
            this.MultipleBtn.OnIdleState.IconRightImage = null;
            this.MultipleBtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.MultipleBtn.OnPressedState.BorderRadius = 1;
            this.MultipleBtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.MultipleBtn.OnPressedState.BorderThickness = 1;
            this.MultipleBtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.MultipleBtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.MultipleBtn.OnPressedState.IconLeftImage = null;
            this.MultipleBtn.OnPressedState.IconRightImage = null;
            this.MultipleBtn.Size = new System.Drawing.Size(75, 75);
            this.MultipleBtn.TabIndex = 18;
            this.MultipleBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.MultipleBtn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.MultipleBtn.TextMarginLeft = 0;
            this.MultipleBtn.TextPadding = new System.Windows.Forms.Padding(0);
            this.MultipleBtn.UseDefaultRadiusAndThickness = true;
            this.MultipleBtn.Click += new System.EventHandler(this.MultipleBtn_Click);
            // 
            // PlusBtn
            // 
            this.PlusBtn.AllowAnimations = true;
            this.PlusBtn.AllowMouseEffects = true;
            this.PlusBtn.AllowToggling = false;
            this.PlusBtn.AnimationSpeed = 200;
            this.PlusBtn.AutoGenerateColors = false;
            this.PlusBtn.AutoRoundBorders = false;
            this.PlusBtn.AutoSizeLeftIcon = true;
            this.PlusBtn.AutoSizeRightIcon = true;
            this.PlusBtn.BackColor = System.Drawing.Color.Transparent;
            this.PlusBtn.BackColor1 = System.Drawing.Color.Yellow;
            this.PlusBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("PlusBtn.BackgroundImage")));
            this.PlusBtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.PlusBtn.ButtonText = "+";
            this.PlusBtn.ButtonTextMarginLeft = 0;
            this.PlusBtn.ColorContrastOnClick = 45;
            this.PlusBtn.ColorContrastOnHover = 45;
            this.PlusBtn.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges23.BottomLeft = true;
            borderEdges23.BottomRight = true;
            borderEdges23.TopLeft = true;
            borderEdges23.TopRight = true;
            this.PlusBtn.CustomizableEdges = borderEdges23;
            this.PlusBtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.PlusBtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.PlusBtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.PlusBtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.PlusBtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.PlusBtn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PlusBtn.ForeColor = System.Drawing.Color.Black;
            this.PlusBtn.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.PlusBtn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.PlusBtn.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.PlusBtn.IconMarginLeft = 11;
            this.PlusBtn.IconPadding = 10;
            this.PlusBtn.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.PlusBtn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.PlusBtn.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.PlusBtn.IconSize = 25;
            this.PlusBtn.IdleBorderColor = System.Drawing.Color.White;
            this.PlusBtn.IdleBorderRadius = 1;
            this.PlusBtn.IdleBorderThickness = 1;
            this.PlusBtn.IdleFillColor = System.Drawing.Color.Yellow;
            this.PlusBtn.IdleIconLeftImage = null;
            this.PlusBtn.IdleIconRightImage = null;
            this.PlusBtn.IndicateFocus = false;
            this.PlusBtn.Location = new System.Drawing.Point(597, 256);
            this.PlusBtn.Name = "PlusBtn";
            this.PlusBtn.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.PlusBtn.OnDisabledState.BorderRadius = 1;
            this.PlusBtn.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.PlusBtn.OnDisabledState.BorderThickness = 1;
            this.PlusBtn.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.PlusBtn.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.PlusBtn.OnDisabledState.IconLeftImage = null;
            this.PlusBtn.OnDisabledState.IconRightImage = null;
            this.PlusBtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.PlusBtn.onHoverState.BorderRadius = 1;
            this.PlusBtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.PlusBtn.onHoverState.BorderThickness = 1;
            this.PlusBtn.onHoverState.FillColor = System.Drawing.Color.Gold;
            this.PlusBtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.PlusBtn.onHoverState.IconLeftImage = null;
            this.PlusBtn.onHoverState.IconRightImage = null;
            this.PlusBtn.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.PlusBtn.OnIdleState.BorderRadius = 1;
            this.PlusBtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.PlusBtn.OnIdleState.BorderThickness = 1;
            this.PlusBtn.OnIdleState.FillColor = System.Drawing.Color.Yellow;
            this.PlusBtn.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.PlusBtn.OnIdleState.IconLeftImage = null;
            this.PlusBtn.OnIdleState.IconRightImage = null;
            this.PlusBtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.PlusBtn.OnPressedState.BorderRadius = 1;
            this.PlusBtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.PlusBtn.OnPressedState.BorderThickness = 1;
            this.PlusBtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.PlusBtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.PlusBtn.OnPressedState.IconLeftImage = null;
            this.PlusBtn.OnPressedState.IconRightImage = null;
            this.PlusBtn.Size = new System.Drawing.Size(75, 75);
            this.PlusBtn.TabIndex = 17;
            this.PlusBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.PlusBtn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.PlusBtn.TextMarginLeft = 0;
            this.PlusBtn.TextPadding = new System.Windows.Forms.Padding(0);
            this.PlusBtn.UseDefaultRadiusAndThickness = true;
            this.PlusBtn.Click += new System.EventHandler(this.PlusBtn_Click);
            // 
            // DivideBtn
            // 
            this.DivideBtn.AllowAnimations = true;
            this.DivideBtn.AllowMouseEffects = true;
            this.DivideBtn.AllowToggling = false;
            this.DivideBtn.AnimationSpeed = 200;
            this.DivideBtn.AutoGenerateColors = false;
            this.DivideBtn.AutoRoundBorders = false;
            this.DivideBtn.AutoSizeLeftIcon = true;
            this.DivideBtn.AutoSizeRightIcon = true;
            this.DivideBtn.BackColor = System.Drawing.Color.Transparent;
            this.DivideBtn.BackColor1 = System.Drawing.Color.Yellow;
            this.DivideBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("DivideBtn.BackgroundImage")));
            this.DivideBtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.DivideBtn.ButtonText = "/";
            this.DivideBtn.ButtonTextMarginLeft = 0;
            this.DivideBtn.ColorContrastOnClick = 45;
            this.DivideBtn.ColorContrastOnHover = 45;
            this.DivideBtn.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges24.BottomLeft = true;
            borderEdges24.BottomRight = true;
            borderEdges24.TopLeft = true;
            borderEdges24.TopRight = true;
            this.DivideBtn.CustomizableEdges = borderEdges24;
            this.DivideBtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.DivideBtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.DivideBtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.DivideBtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.DivideBtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.DivideBtn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DivideBtn.ForeColor = System.Drawing.Color.Black;
            this.DivideBtn.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DivideBtn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.DivideBtn.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.DivideBtn.IconMarginLeft = 11;
            this.DivideBtn.IconPadding = 10;
            this.DivideBtn.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.DivideBtn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.DivideBtn.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.DivideBtn.IconSize = 25;
            this.DivideBtn.IdleBorderColor = System.Drawing.Color.White;
            this.DivideBtn.IdleBorderRadius = 1;
            this.DivideBtn.IdleBorderThickness = 1;
            this.DivideBtn.IdleFillColor = System.Drawing.Color.Yellow;
            this.DivideBtn.IdleIconLeftImage = null;
            this.DivideBtn.IdleIconRightImage = null;
            this.DivideBtn.IndicateFocus = false;
            this.DivideBtn.Location = new System.Drawing.Point(481, 375);
            this.DivideBtn.Name = "DivideBtn";
            this.DivideBtn.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.DivideBtn.OnDisabledState.BorderRadius = 1;
            this.DivideBtn.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.DivideBtn.OnDisabledState.BorderThickness = 1;
            this.DivideBtn.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.DivideBtn.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.DivideBtn.OnDisabledState.IconLeftImage = null;
            this.DivideBtn.OnDisabledState.IconRightImage = null;
            this.DivideBtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.DivideBtn.onHoverState.BorderRadius = 1;
            this.DivideBtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.DivideBtn.onHoverState.BorderThickness = 1;
            this.DivideBtn.onHoverState.FillColor = System.Drawing.Color.Gold;
            this.DivideBtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.DivideBtn.onHoverState.IconLeftImage = null;
            this.DivideBtn.onHoverState.IconRightImage = null;
            this.DivideBtn.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.DivideBtn.OnIdleState.BorderRadius = 1;
            this.DivideBtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.DivideBtn.OnIdleState.BorderThickness = 1;
            this.DivideBtn.OnIdleState.FillColor = System.Drawing.Color.Yellow;
            this.DivideBtn.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.DivideBtn.OnIdleState.IconLeftImage = null;
            this.DivideBtn.OnIdleState.IconRightImage = null;
            this.DivideBtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.DivideBtn.OnPressedState.BorderRadius = 1;
            this.DivideBtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.DivideBtn.OnPressedState.BorderThickness = 1;
            this.DivideBtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.DivideBtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.DivideBtn.OnPressedState.IconLeftImage = null;
            this.DivideBtn.OnPressedState.IconRightImage = null;
            this.DivideBtn.Size = new System.Drawing.Size(75, 75);
            this.DivideBtn.TabIndex = 16;
            this.DivideBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.DivideBtn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.DivideBtn.TextMarginLeft = 0;
            this.DivideBtn.TextPadding = new System.Windows.Forms.Padding(0);
            this.DivideBtn.UseDefaultRadiusAndThickness = true;
            this.DivideBtn.Click += new System.EventHandler(this.DivideBtn_Click);
            // 
            // MinusBtn
            // 
            this.MinusBtn.AllowAnimations = true;
            this.MinusBtn.AllowMouseEffects = true;
            this.MinusBtn.AllowToggling = false;
            this.MinusBtn.AnimationSpeed = 200;
            this.MinusBtn.AutoGenerateColors = false;
            this.MinusBtn.AutoRoundBorders = false;
            this.MinusBtn.AutoSizeLeftIcon = true;
            this.MinusBtn.AutoSizeRightIcon = true;
            this.MinusBtn.BackColor = System.Drawing.Color.Transparent;
            this.MinusBtn.BackColor1 = System.Drawing.Color.Yellow;
            this.MinusBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("MinusBtn.BackgroundImage")));
            this.MinusBtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.MinusBtn.ButtonText = "-";
            this.MinusBtn.ButtonTextMarginLeft = 0;
            this.MinusBtn.ColorContrastOnClick = 45;
            this.MinusBtn.ColorContrastOnHover = 45;
            this.MinusBtn.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges25.BottomLeft = true;
            borderEdges25.BottomRight = true;
            borderEdges25.TopLeft = true;
            borderEdges25.TopRight = true;
            this.MinusBtn.CustomizableEdges = borderEdges25;
            this.MinusBtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.MinusBtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.MinusBtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.MinusBtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.MinusBtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.MinusBtn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MinusBtn.ForeColor = System.Drawing.Color.Black;
            this.MinusBtn.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.MinusBtn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.MinusBtn.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.MinusBtn.IconMarginLeft = 11;
            this.MinusBtn.IconPadding = 10;
            this.MinusBtn.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.MinusBtn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.MinusBtn.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.MinusBtn.IconSize = 25;
            this.MinusBtn.IdleBorderColor = System.Drawing.Color.White;
            this.MinusBtn.IdleBorderRadius = 1;
            this.MinusBtn.IdleBorderThickness = 1;
            this.MinusBtn.IdleFillColor = System.Drawing.Color.Yellow;
            this.MinusBtn.IdleIconLeftImage = null;
            this.MinusBtn.IdleIconRightImage = null;
            this.MinusBtn.IndicateFocus = false;
            this.MinusBtn.Location = new System.Drawing.Point(481, 256);
            this.MinusBtn.Name = "MinusBtn";
            this.MinusBtn.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.MinusBtn.OnDisabledState.BorderRadius = 1;
            this.MinusBtn.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.MinusBtn.OnDisabledState.BorderThickness = 1;
            this.MinusBtn.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.MinusBtn.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.MinusBtn.OnDisabledState.IconLeftImage = null;
            this.MinusBtn.OnDisabledState.IconRightImage = null;
            this.MinusBtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.MinusBtn.onHoverState.BorderRadius = 1;
            this.MinusBtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.MinusBtn.onHoverState.BorderThickness = 1;
            this.MinusBtn.onHoverState.FillColor = System.Drawing.Color.Gold;
            this.MinusBtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.MinusBtn.onHoverState.IconLeftImage = null;
            this.MinusBtn.onHoverState.IconRightImage = null;
            this.MinusBtn.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.MinusBtn.OnIdleState.BorderRadius = 1;
            this.MinusBtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.MinusBtn.OnIdleState.BorderThickness = 1;
            this.MinusBtn.OnIdleState.FillColor = System.Drawing.Color.Yellow;
            this.MinusBtn.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.MinusBtn.OnIdleState.IconLeftImage = null;
            this.MinusBtn.OnIdleState.IconRightImage = null;
            this.MinusBtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.MinusBtn.OnPressedState.BorderRadius = 1;
            this.MinusBtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.MinusBtn.OnPressedState.BorderThickness = 1;
            this.MinusBtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.MinusBtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.MinusBtn.OnPressedState.IconLeftImage = null;
            this.MinusBtn.OnPressedState.IconRightImage = null;
            this.MinusBtn.Size = new System.Drawing.Size(75, 75);
            this.MinusBtn.TabIndex = 15;
            this.MinusBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.MinusBtn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.MinusBtn.TextMarginLeft = 0;
            this.MinusBtn.TextPadding = new System.Windows.Forms.Padding(0);
            this.MinusBtn.UseDefaultRadiusAndThickness = true;
            this.MinusBtn.Click += new System.EventHandler(this.MinusBtn_Click);
            // 
            // ClearBtn
            // 
            this.ClearBtn.AllowAnimations = true;
            this.ClearBtn.AllowMouseEffects = true;
            this.ClearBtn.AllowToggling = false;
            this.ClearBtn.AnimationSpeed = 200;
            this.ClearBtn.AutoGenerateColors = false;
            this.ClearBtn.AutoRoundBorders = false;
            this.ClearBtn.AutoSizeLeftIcon = true;
            this.ClearBtn.AutoSizeRightIcon = true;
            this.ClearBtn.BackColor = System.Drawing.Color.Transparent;
            this.ClearBtn.BackColor1 = System.Drawing.Color.Yellow;
            this.ClearBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ClearBtn.BackgroundImage")));
            this.ClearBtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ClearBtn.ButtonText = "Clear";
            this.ClearBtn.ButtonTextMarginLeft = 0;
            this.ClearBtn.ColorContrastOnClick = 45;
            this.ClearBtn.ColorContrastOnHover = 45;
            this.ClearBtn.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges26.BottomLeft = true;
            borderEdges26.BottomRight = true;
            borderEdges26.TopLeft = true;
            borderEdges26.TopRight = true;
            this.ClearBtn.CustomizableEdges = borderEdges26;
            this.ClearBtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.ClearBtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.ClearBtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ClearBtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.ClearBtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.ClearBtn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ClearBtn.ForeColor = System.Drawing.Color.Black;
            this.ClearBtn.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ClearBtn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.ClearBtn.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.ClearBtn.IconMarginLeft = 11;
            this.ClearBtn.IconPadding = 10;
            this.ClearBtn.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ClearBtn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.ClearBtn.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.ClearBtn.IconSize = 25;
            this.ClearBtn.IdleBorderColor = System.Drawing.Color.White;
            this.ClearBtn.IdleBorderRadius = 1;
            this.ClearBtn.IdleBorderThickness = 1;
            this.ClearBtn.IdleFillColor = System.Drawing.Color.Yellow;
            this.ClearBtn.IdleIconLeftImage = null;
            this.ClearBtn.IdleIconRightImage = null;
            this.ClearBtn.IndicateFocus = false;
            this.ClearBtn.Location = new System.Drawing.Point(495, 177);
            this.ClearBtn.Name = "ClearBtn";
            this.ClearBtn.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.ClearBtn.OnDisabledState.BorderRadius = 1;
            this.ClearBtn.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ClearBtn.OnDisabledState.BorderThickness = 1;
            this.ClearBtn.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ClearBtn.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.ClearBtn.OnDisabledState.IconLeftImage = null;
            this.ClearBtn.OnDisabledState.IconRightImage = null;
            this.ClearBtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.ClearBtn.onHoverState.BorderRadius = 1;
            this.ClearBtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ClearBtn.onHoverState.BorderThickness = 1;
            this.ClearBtn.onHoverState.FillColor = System.Drawing.Color.Gold;
            this.ClearBtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.ClearBtn.onHoverState.IconLeftImage = null;
            this.ClearBtn.onHoverState.IconRightImage = null;
            this.ClearBtn.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.ClearBtn.OnIdleState.BorderRadius = 1;
            this.ClearBtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ClearBtn.OnIdleState.BorderThickness = 1;
            this.ClearBtn.OnIdleState.FillColor = System.Drawing.Color.Yellow;
            this.ClearBtn.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.ClearBtn.OnIdleState.IconLeftImage = null;
            this.ClearBtn.OnIdleState.IconRightImage = null;
            this.ClearBtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.ClearBtn.OnPressedState.BorderRadius = 1;
            this.ClearBtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ClearBtn.OnPressedState.BorderThickness = 1;
            this.ClearBtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.ClearBtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.ClearBtn.OnPressedState.IconLeftImage = null;
            this.ClearBtn.OnPressedState.IconRightImage = null;
            this.ClearBtn.Size = new System.Drawing.Size(172, 59);
            this.ClearBtn.TabIndex = 14;
            this.ClearBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ClearBtn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.ClearBtn.TextMarginLeft = 0;
            this.ClearBtn.TextPadding = new System.Windows.Forms.Padding(0);
            this.ClearBtn.UseDefaultRadiusAndThickness = true;
            this.ClearBtn.Click += new System.EventHandler(this.ClearBtn_Click);
            // 
            // EqualBtn
            // 
            this.EqualBtn.AllowAnimations = true;
            this.EqualBtn.AllowMouseEffects = true;
            this.EqualBtn.AllowToggling = false;
            this.EqualBtn.AnimationSpeed = 200;
            this.EqualBtn.AutoGenerateColors = false;
            this.EqualBtn.AutoRoundBorders = false;
            this.EqualBtn.AutoSizeLeftIcon = true;
            this.EqualBtn.AutoSizeRightIcon = true;
            this.EqualBtn.BackColor = System.Drawing.Color.Transparent;
            this.EqualBtn.BackColor1 = System.Drawing.Color.Yellow;
            this.EqualBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("EqualBtn.BackgroundImage")));
            this.EqualBtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.EqualBtn.ButtonText = "=";
            this.EqualBtn.ButtonTextMarginLeft = 0;
            this.EqualBtn.ColorContrastOnClick = 45;
            this.EqualBtn.ColorContrastOnHover = 45;
            this.EqualBtn.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges27.BottomLeft = true;
            borderEdges27.BottomRight = true;
            borderEdges27.TopLeft = true;
            borderEdges27.TopRight = true;
            this.EqualBtn.CustomizableEdges = borderEdges27;
            this.EqualBtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.EqualBtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.EqualBtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.EqualBtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.EqualBtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.EqualBtn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EqualBtn.ForeColor = System.Drawing.Color.Black;
            this.EqualBtn.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.EqualBtn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.EqualBtn.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.EqualBtn.IconMarginLeft = 11;
            this.EqualBtn.IconPadding = 10;
            this.EqualBtn.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.EqualBtn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.EqualBtn.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.EqualBtn.IconSize = 25;
            this.EqualBtn.IdleBorderColor = System.Drawing.Color.White;
            this.EqualBtn.IdleBorderRadius = 1;
            this.EqualBtn.IdleBorderThickness = 1;
            this.EqualBtn.IdleFillColor = System.Drawing.Color.Yellow;
            this.EqualBtn.IdleIconLeftImage = null;
            this.EqualBtn.IdleIconRightImage = null;
            this.EqualBtn.IndicateFocus = false;
            this.EqualBtn.Location = new System.Drawing.Point(264, 437);
            this.EqualBtn.Name = "EqualBtn";
            this.EqualBtn.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.EqualBtn.OnDisabledState.BorderRadius = 1;
            this.EqualBtn.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.EqualBtn.OnDisabledState.BorderThickness = 1;
            this.EqualBtn.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.EqualBtn.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.EqualBtn.OnDisabledState.IconLeftImage = null;
            this.EqualBtn.OnDisabledState.IconRightImage = null;
            this.EqualBtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.EqualBtn.onHoverState.BorderRadius = 1;
            this.EqualBtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.EqualBtn.onHoverState.BorderThickness = 1;
            this.EqualBtn.onHoverState.FillColor = System.Drawing.Color.Gold;
            this.EqualBtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.EqualBtn.onHoverState.IconLeftImage = null;
            this.EqualBtn.onHoverState.IconRightImage = null;
            this.EqualBtn.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.EqualBtn.OnIdleState.BorderRadius = 1;
            this.EqualBtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.EqualBtn.OnIdleState.BorderThickness = 1;
            this.EqualBtn.OnIdleState.FillColor = System.Drawing.Color.Yellow;
            this.EqualBtn.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.EqualBtn.OnIdleState.IconLeftImage = null;
            this.EqualBtn.OnIdleState.IconRightImage = null;
            this.EqualBtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.EqualBtn.OnPressedState.BorderRadius = 1;
            this.EqualBtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.EqualBtn.OnPressedState.BorderThickness = 1;
            this.EqualBtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.EqualBtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.EqualBtn.OnPressedState.IconLeftImage = null;
            this.EqualBtn.OnPressedState.IconRightImage = null;
            this.EqualBtn.Size = new System.Drawing.Size(75, 75);
            this.EqualBtn.TabIndex = 13;
            this.EqualBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.EqualBtn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.EqualBtn.TextMarginLeft = 0;
            this.EqualBtn.TextPadding = new System.Windows.Forms.Padding(0);
            this.EqualBtn.UseDefaultRadiusAndThickness = true;
            this.EqualBtn.Click += new System.EventHandler(this.EqualBtn_Click);
            // 
            // DotBtn
            // 
            this.DotBtn.AllowAnimations = true;
            this.DotBtn.AllowMouseEffects = true;
            this.DotBtn.AllowToggling = false;
            this.DotBtn.AnimationSpeed = 200;
            this.DotBtn.AutoGenerateColors = false;
            this.DotBtn.AutoRoundBorders = false;
            this.DotBtn.AutoSizeLeftIcon = true;
            this.DotBtn.AutoSizeRightIcon = true;
            this.DotBtn.BackColor = System.Drawing.Color.Transparent;
            this.DotBtn.BackColor1 = System.Drawing.Color.Yellow;
            this.DotBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("DotBtn.BackgroundImage")));
            this.DotBtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.DotBtn.ButtonText = ".";
            this.DotBtn.ButtonTextMarginLeft = 0;
            this.DotBtn.ColorContrastOnClick = 45;
            this.DotBtn.ColorContrastOnHover = 45;
            this.DotBtn.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges28.BottomLeft = true;
            borderEdges28.BottomRight = true;
            borderEdges28.TopLeft = true;
            borderEdges28.TopRight = true;
            this.DotBtn.CustomizableEdges = borderEdges28;
            this.DotBtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.DotBtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.DotBtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.DotBtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.DotBtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.DotBtn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DotBtn.ForeColor = System.Drawing.Color.Black;
            this.DotBtn.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.DotBtn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.DotBtn.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.DotBtn.IconMarginLeft = 11;
            this.DotBtn.IconPadding = 10;
            this.DotBtn.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.DotBtn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.DotBtn.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.DotBtn.IconSize = 25;
            this.DotBtn.IdleBorderColor = System.Drawing.Color.White;
            this.DotBtn.IdleBorderRadius = 1;
            this.DotBtn.IdleBorderThickness = 1;
            this.DotBtn.IdleFillColor = System.Drawing.Color.Yellow;
            this.DotBtn.IdleIconLeftImage = null;
            this.DotBtn.IdleIconRightImage = null;
            this.DotBtn.IndicateFocus = false;
            this.DotBtn.Location = new System.Drawing.Point(168, 436);
            this.DotBtn.Name = "DotBtn";
            this.DotBtn.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.DotBtn.OnDisabledState.BorderRadius = 1;
            this.DotBtn.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.DotBtn.OnDisabledState.BorderThickness = 1;
            this.DotBtn.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.DotBtn.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.DotBtn.OnDisabledState.IconLeftImage = null;
            this.DotBtn.OnDisabledState.IconRightImage = null;
            this.DotBtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.DotBtn.onHoverState.BorderRadius = 1;
            this.DotBtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.DotBtn.onHoverState.BorderThickness = 1;
            this.DotBtn.onHoverState.FillColor = System.Drawing.Color.Gold;
            this.DotBtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.DotBtn.onHoverState.IconLeftImage = null;
            this.DotBtn.onHoverState.IconRightImage = null;
            this.DotBtn.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.DotBtn.OnIdleState.BorderRadius = 1;
            this.DotBtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.DotBtn.OnIdleState.BorderThickness = 1;
            this.DotBtn.OnIdleState.FillColor = System.Drawing.Color.Yellow;
            this.DotBtn.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.DotBtn.OnIdleState.IconLeftImage = null;
            this.DotBtn.OnIdleState.IconRightImage = null;
            this.DotBtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.DotBtn.OnPressedState.BorderRadius = 1;
            this.DotBtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.DotBtn.OnPressedState.BorderThickness = 1;
            this.DotBtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.DotBtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.DotBtn.OnPressedState.IconLeftImage = null;
            this.DotBtn.OnPressedState.IconRightImage = null;
            this.DotBtn.Size = new System.Drawing.Size(75, 75);
            this.DotBtn.TabIndex = 12;
            this.DotBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.DotBtn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.DotBtn.TextMarginLeft = 0;
            this.DotBtn.TextPadding = new System.Windows.Forms.Padding(0);
            this.DotBtn.UseDefaultRadiusAndThickness = true;
            this.DotBtn.Click += new System.EventHandler(this.DotBtn_Click);
            // 
            // ZeroBtn
            // 
            this.ZeroBtn.AllowAnimations = true;
            this.ZeroBtn.AllowMouseEffects = true;
            this.ZeroBtn.AllowToggling = false;
            this.ZeroBtn.AnimationSpeed = 200;
            this.ZeroBtn.AutoGenerateColors = false;
            this.ZeroBtn.AutoRoundBorders = false;
            this.ZeroBtn.AutoSizeLeftIcon = true;
            this.ZeroBtn.AutoSizeRightIcon = true;
            this.ZeroBtn.BackColor = System.Drawing.Color.Transparent;
            this.ZeroBtn.BackColor1 = System.Drawing.Color.Yellow;
            this.ZeroBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ZeroBtn.BackgroundImage")));
            this.ZeroBtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ZeroBtn.ButtonText = "0";
            this.ZeroBtn.ButtonTextMarginLeft = 0;
            this.ZeroBtn.ColorContrastOnClick = 45;
            this.ZeroBtn.ColorContrastOnHover = 45;
            this.ZeroBtn.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges29.BottomLeft = true;
            borderEdges29.BottomRight = true;
            borderEdges29.TopLeft = true;
            borderEdges29.TopRight = true;
            this.ZeroBtn.CustomizableEdges = borderEdges29;
            this.ZeroBtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.ZeroBtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.ZeroBtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ZeroBtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.ZeroBtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.ZeroBtn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ZeroBtn.ForeColor = System.Drawing.Color.Black;
            this.ZeroBtn.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ZeroBtn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.ZeroBtn.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.ZeroBtn.IconMarginLeft = 11;
            this.ZeroBtn.IconPadding = 10;
            this.ZeroBtn.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ZeroBtn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.ZeroBtn.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.ZeroBtn.IconSize = 25;
            this.ZeroBtn.IdleBorderColor = System.Drawing.Color.White;
            this.ZeroBtn.IdleBorderRadius = 1;
            this.ZeroBtn.IdleBorderThickness = 1;
            this.ZeroBtn.IdleFillColor = System.Drawing.Color.Yellow;
            this.ZeroBtn.IdleIconLeftImage = null;
            this.ZeroBtn.IdleIconRightImage = null;
            this.ZeroBtn.IndicateFocus = false;
            this.ZeroBtn.Location = new System.Drawing.Point(69, 436);
            this.ZeroBtn.Name = "ZeroBtn";
            this.ZeroBtn.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.ZeroBtn.OnDisabledState.BorderRadius = 1;
            this.ZeroBtn.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ZeroBtn.OnDisabledState.BorderThickness = 1;
            this.ZeroBtn.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ZeroBtn.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.ZeroBtn.OnDisabledState.IconLeftImage = null;
            this.ZeroBtn.OnDisabledState.IconRightImage = null;
            this.ZeroBtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.ZeroBtn.onHoverState.BorderRadius = 1;
            this.ZeroBtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ZeroBtn.onHoverState.BorderThickness = 1;
            this.ZeroBtn.onHoverState.FillColor = System.Drawing.Color.Gold;
            this.ZeroBtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.ZeroBtn.onHoverState.IconLeftImage = null;
            this.ZeroBtn.onHoverState.IconRightImage = null;
            this.ZeroBtn.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.ZeroBtn.OnIdleState.BorderRadius = 1;
            this.ZeroBtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ZeroBtn.OnIdleState.BorderThickness = 1;
            this.ZeroBtn.OnIdleState.FillColor = System.Drawing.Color.Yellow;
            this.ZeroBtn.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.ZeroBtn.OnIdleState.IconLeftImage = null;
            this.ZeroBtn.OnIdleState.IconRightImage = null;
            this.ZeroBtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.ZeroBtn.OnPressedState.BorderRadius = 1;
            this.ZeroBtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ZeroBtn.OnPressedState.BorderThickness = 1;
            this.ZeroBtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.ZeroBtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.ZeroBtn.OnPressedState.IconLeftImage = null;
            this.ZeroBtn.OnPressedState.IconRightImage = null;
            this.ZeroBtn.Size = new System.Drawing.Size(75, 75);
            this.ZeroBtn.TabIndex = 11;
            this.ZeroBtn.TabStop = false;
            this.ZeroBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ZeroBtn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.ZeroBtn.TextMarginLeft = 0;
            this.ZeroBtn.TextPadding = new System.Windows.Forms.Padding(0);
            this.ZeroBtn.UseDefaultRadiusAndThickness = true;
            this.ZeroBtn.Click += new System.EventHandler(this.ZeroBtn_Click);
            // 
            // SixBtn
            // 
            this.SixBtn.AllowAnimations = true;
            this.SixBtn.AllowMouseEffects = true;
            this.SixBtn.AllowToggling = false;
            this.SixBtn.AnimationSpeed = 200;
            this.SixBtn.AutoGenerateColors = false;
            this.SixBtn.AutoRoundBorders = false;
            this.SixBtn.AutoSizeLeftIcon = true;
            this.SixBtn.AutoSizeRightIcon = true;
            this.SixBtn.BackColor = System.Drawing.Color.Transparent;
            this.SixBtn.BackColor1 = System.Drawing.Color.Yellow;
            this.SixBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("SixBtn.BackgroundImage")));
            this.SixBtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.SixBtn.ButtonText = "6";
            this.SixBtn.ButtonTextMarginLeft = 0;
            this.SixBtn.ColorContrastOnClick = 45;
            this.SixBtn.ColorContrastOnHover = 45;
            this.SixBtn.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges30.BottomLeft = true;
            borderEdges30.BottomRight = true;
            borderEdges30.TopLeft = true;
            borderEdges30.TopRight = true;
            this.SixBtn.CustomizableEdges = borderEdges30;
            this.SixBtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.SixBtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.SixBtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.SixBtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.SixBtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.SixBtn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SixBtn.ForeColor = System.Drawing.Color.Black;
            this.SixBtn.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SixBtn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.SixBtn.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.SixBtn.IconMarginLeft = 11;
            this.SixBtn.IconPadding = 10;
            this.SixBtn.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SixBtn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.SixBtn.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.SixBtn.IconSize = 25;
            this.SixBtn.IdleBorderColor = System.Drawing.Color.White;
            this.SixBtn.IdleBorderRadius = 1;
            this.SixBtn.IdleBorderThickness = 1;
            this.SixBtn.IdleFillColor = System.Drawing.Color.Yellow;
            this.SixBtn.IdleIconLeftImage = null;
            this.SixBtn.IdleIconRightImage = null;
            this.SixBtn.IndicateFocus = false;
            this.SixBtn.Location = new System.Drawing.Point(264, 253);
            this.SixBtn.Name = "SixBtn";
            this.SixBtn.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.SixBtn.OnDisabledState.BorderRadius = 1;
            this.SixBtn.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.SixBtn.OnDisabledState.BorderThickness = 1;
            this.SixBtn.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.SixBtn.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.SixBtn.OnDisabledState.IconLeftImage = null;
            this.SixBtn.OnDisabledState.IconRightImage = null;
            this.SixBtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.SixBtn.onHoverState.BorderRadius = 1;
            this.SixBtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.SixBtn.onHoverState.BorderThickness = 1;
            this.SixBtn.onHoverState.FillColor = System.Drawing.Color.Gold;
            this.SixBtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.SixBtn.onHoverState.IconLeftImage = null;
            this.SixBtn.onHoverState.IconRightImage = null;
            this.SixBtn.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.SixBtn.OnIdleState.BorderRadius = 1;
            this.SixBtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.SixBtn.OnIdleState.BorderThickness = 1;
            this.SixBtn.OnIdleState.FillColor = System.Drawing.Color.Yellow;
            this.SixBtn.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.SixBtn.OnIdleState.IconLeftImage = null;
            this.SixBtn.OnIdleState.IconRightImage = null;
            this.SixBtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.SixBtn.OnPressedState.BorderRadius = 1;
            this.SixBtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.SixBtn.OnPressedState.BorderThickness = 1;
            this.SixBtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.SixBtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.SixBtn.OnPressedState.IconLeftImage = null;
            this.SixBtn.OnPressedState.IconRightImage = null;
            this.SixBtn.Size = new System.Drawing.Size(75, 75);
            this.SixBtn.TabIndex = 10;
            this.SixBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.SixBtn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.SixBtn.TextMarginLeft = 0;
            this.SixBtn.TextPadding = new System.Windows.Forms.Padding(0);
            this.SixBtn.UseDefaultRadiusAndThickness = true;
            this.SixBtn.Click += new System.EventHandler(this.SixBtn_Click);
            // 
            // OneBtn
            // 
            this.OneBtn.AllowAnimations = true;
            this.OneBtn.AllowMouseEffects = true;
            this.OneBtn.AllowToggling = false;
            this.OneBtn.AnimationSpeed = 200;
            this.OneBtn.AutoGenerateColors = false;
            this.OneBtn.AutoRoundBorders = false;
            this.OneBtn.AutoSizeLeftIcon = true;
            this.OneBtn.AutoSizeRightIcon = true;
            this.OneBtn.BackColor = System.Drawing.Color.Transparent;
            this.OneBtn.BackColor1 = System.Drawing.Color.Yellow;
            this.OneBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("OneBtn.BackgroundImage")));
            this.OneBtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.OneBtn.ButtonText = "1";
            this.OneBtn.ButtonTextMarginLeft = 0;
            this.OneBtn.ColorContrastOnClick = 45;
            this.OneBtn.ColorContrastOnHover = 45;
            this.OneBtn.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges31.BottomLeft = true;
            borderEdges31.BottomRight = true;
            borderEdges31.TopLeft = true;
            borderEdges31.TopRight = true;
            this.OneBtn.CustomizableEdges = borderEdges31;
            this.OneBtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.OneBtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.OneBtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.OneBtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.OneBtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.OneBtn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OneBtn.ForeColor = System.Drawing.Color.Black;
            this.OneBtn.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.OneBtn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.OneBtn.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.OneBtn.IconMarginLeft = 11;
            this.OneBtn.IconPadding = 10;
            this.OneBtn.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.OneBtn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.OneBtn.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.OneBtn.IconSize = 25;
            this.OneBtn.IdleBorderColor = System.Drawing.Color.White;
            this.OneBtn.IdleBorderRadius = 1;
            this.OneBtn.IdleBorderThickness = 1;
            this.OneBtn.IdleFillColor = System.Drawing.Color.Yellow;
            this.OneBtn.IdleIconLeftImage = null;
            this.OneBtn.IdleIconRightImage = null;
            this.OneBtn.IndicateFocus = false;
            this.OneBtn.Location = new System.Drawing.Point(69, 343);
            this.OneBtn.Name = "OneBtn";
            this.OneBtn.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.OneBtn.OnDisabledState.BorderRadius = 1;
            this.OneBtn.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.OneBtn.OnDisabledState.BorderThickness = 1;
            this.OneBtn.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.OneBtn.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.OneBtn.OnDisabledState.IconLeftImage = null;
            this.OneBtn.OnDisabledState.IconRightImage = null;
            this.OneBtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.OneBtn.onHoverState.BorderRadius = 1;
            this.OneBtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.OneBtn.onHoverState.BorderThickness = 1;
            this.OneBtn.onHoverState.FillColor = System.Drawing.Color.Gold;
            this.OneBtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.OneBtn.onHoverState.IconLeftImage = null;
            this.OneBtn.onHoverState.IconRightImage = null;
            this.OneBtn.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.OneBtn.OnIdleState.BorderRadius = 1;
            this.OneBtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.OneBtn.OnIdleState.BorderThickness = 1;
            this.OneBtn.OnIdleState.FillColor = System.Drawing.Color.Yellow;
            this.OneBtn.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.OneBtn.OnIdleState.IconLeftImage = null;
            this.OneBtn.OnIdleState.IconRightImage = null;
            this.OneBtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.OneBtn.OnPressedState.BorderRadius = 1;
            this.OneBtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.OneBtn.OnPressedState.BorderThickness = 1;
            this.OneBtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.OneBtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.OneBtn.OnPressedState.IconLeftImage = null;
            this.OneBtn.OnPressedState.IconRightImage = null;
            this.OneBtn.Size = new System.Drawing.Size(75, 75);
            this.OneBtn.TabIndex = 9;
            this.OneBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.OneBtn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.OneBtn.TextMarginLeft = 0;
            this.OneBtn.TextPadding = new System.Windows.Forms.Padding(0);
            this.OneBtn.UseDefaultRadiusAndThickness = true;
            this.OneBtn.Click += new System.EventHandler(this.OneBtn_Click);
            // 
            // TwoBtn
            // 
            this.TwoBtn.AllowAnimations = true;
            this.TwoBtn.AllowMouseEffects = true;
            this.TwoBtn.AllowToggling = false;
            this.TwoBtn.AnimationSpeed = 200;
            this.TwoBtn.AutoGenerateColors = false;
            this.TwoBtn.AutoRoundBorders = false;
            this.TwoBtn.AutoSizeLeftIcon = true;
            this.TwoBtn.AutoSizeRightIcon = true;
            this.TwoBtn.BackColor = System.Drawing.Color.Transparent;
            this.TwoBtn.BackColor1 = System.Drawing.Color.Yellow;
            this.TwoBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("TwoBtn.BackgroundImage")));
            this.TwoBtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.TwoBtn.ButtonText = "2";
            this.TwoBtn.ButtonTextMarginLeft = 0;
            this.TwoBtn.ColorContrastOnClick = 45;
            this.TwoBtn.ColorContrastOnHover = 45;
            this.TwoBtn.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges32.BottomLeft = true;
            borderEdges32.BottomRight = true;
            borderEdges32.TopLeft = true;
            borderEdges32.TopRight = true;
            this.TwoBtn.CustomizableEdges = borderEdges32;
            this.TwoBtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.TwoBtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.TwoBtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.TwoBtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.TwoBtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.TwoBtn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TwoBtn.ForeColor = System.Drawing.Color.Black;
            this.TwoBtn.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.TwoBtn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.TwoBtn.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.TwoBtn.IconMarginLeft = 11;
            this.TwoBtn.IconPadding = 10;
            this.TwoBtn.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.TwoBtn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.TwoBtn.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.TwoBtn.IconSize = 25;
            this.TwoBtn.IdleBorderColor = System.Drawing.Color.White;
            this.TwoBtn.IdleBorderRadius = 1;
            this.TwoBtn.IdleBorderThickness = 1;
            this.TwoBtn.IdleFillColor = System.Drawing.Color.Yellow;
            this.TwoBtn.IdleIconLeftImage = null;
            this.TwoBtn.IdleIconRightImage = null;
            this.TwoBtn.IndicateFocus = false;
            this.TwoBtn.Location = new System.Drawing.Point(168, 343);
            this.TwoBtn.Name = "TwoBtn";
            this.TwoBtn.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.TwoBtn.OnDisabledState.BorderRadius = 1;
            this.TwoBtn.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.TwoBtn.OnDisabledState.BorderThickness = 1;
            this.TwoBtn.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.TwoBtn.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.TwoBtn.OnDisabledState.IconLeftImage = null;
            this.TwoBtn.OnDisabledState.IconRightImage = null;
            this.TwoBtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.TwoBtn.onHoverState.BorderRadius = 1;
            this.TwoBtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.TwoBtn.onHoverState.BorderThickness = 1;
            this.TwoBtn.onHoverState.FillColor = System.Drawing.Color.Gold;
            this.TwoBtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.TwoBtn.onHoverState.IconLeftImage = null;
            this.TwoBtn.onHoverState.IconRightImage = null;
            this.TwoBtn.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.TwoBtn.OnIdleState.BorderRadius = 1;
            this.TwoBtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.TwoBtn.OnIdleState.BorderThickness = 1;
            this.TwoBtn.OnIdleState.FillColor = System.Drawing.Color.Yellow;
            this.TwoBtn.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.TwoBtn.OnIdleState.IconLeftImage = null;
            this.TwoBtn.OnIdleState.IconRightImage = null;
            this.TwoBtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.TwoBtn.OnPressedState.BorderRadius = 1;
            this.TwoBtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.TwoBtn.OnPressedState.BorderThickness = 1;
            this.TwoBtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.TwoBtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.TwoBtn.OnPressedState.IconLeftImage = null;
            this.TwoBtn.OnPressedState.IconRightImage = null;
            this.TwoBtn.Size = new System.Drawing.Size(75, 75);
            this.TwoBtn.TabIndex = 8;
            this.TwoBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.TwoBtn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.TwoBtn.TextMarginLeft = 0;
            this.TwoBtn.TextPadding = new System.Windows.Forms.Padding(0);
            this.TwoBtn.UseDefaultRadiusAndThickness = true;
            this.TwoBtn.Click += new System.EventHandler(this.TwoBtn_Click);
            // 
            // ThreeBtn
            // 
            this.ThreeBtn.AllowAnimations = true;
            this.ThreeBtn.AllowMouseEffects = true;
            this.ThreeBtn.AllowToggling = false;
            this.ThreeBtn.AnimationSpeed = 200;
            this.ThreeBtn.AutoGenerateColors = false;
            this.ThreeBtn.AutoRoundBorders = false;
            this.ThreeBtn.AutoSizeLeftIcon = true;
            this.ThreeBtn.AutoSizeRightIcon = true;
            this.ThreeBtn.BackColor = System.Drawing.Color.Transparent;
            this.ThreeBtn.BackColor1 = System.Drawing.Color.Yellow;
            this.ThreeBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("ThreeBtn.BackgroundImage")));
            this.ThreeBtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ThreeBtn.ButtonText = "3";
            this.ThreeBtn.ButtonTextMarginLeft = 0;
            this.ThreeBtn.ColorContrastOnClick = 45;
            this.ThreeBtn.ColorContrastOnHover = 45;
            this.ThreeBtn.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges33.BottomLeft = true;
            borderEdges33.BottomRight = true;
            borderEdges33.TopLeft = true;
            borderEdges33.TopRight = true;
            this.ThreeBtn.CustomizableEdges = borderEdges33;
            this.ThreeBtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.ThreeBtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.ThreeBtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ThreeBtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.ThreeBtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.ThreeBtn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ThreeBtn.ForeColor = System.Drawing.Color.Black;
            this.ThreeBtn.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.ThreeBtn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.ThreeBtn.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.ThreeBtn.IconMarginLeft = 11;
            this.ThreeBtn.IconPadding = 10;
            this.ThreeBtn.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.ThreeBtn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.ThreeBtn.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.ThreeBtn.IconSize = 25;
            this.ThreeBtn.IdleBorderColor = System.Drawing.Color.White;
            this.ThreeBtn.IdleBorderRadius = 1;
            this.ThreeBtn.IdleBorderThickness = 1;
            this.ThreeBtn.IdleFillColor = System.Drawing.Color.Yellow;
            this.ThreeBtn.IdleIconLeftImage = null;
            this.ThreeBtn.IdleIconRightImage = null;
            this.ThreeBtn.IndicateFocus = false;
            this.ThreeBtn.Location = new System.Drawing.Point(264, 343);
            this.ThreeBtn.Name = "ThreeBtn";
            this.ThreeBtn.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.ThreeBtn.OnDisabledState.BorderRadius = 1;
            this.ThreeBtn.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ThreeBtn.OnDisabledState.BorderThickness = 1;
            this.ThreeBtn.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.ThreeBtn.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.ThreeBtn.OnDisabledState.IconLeftImage = null;
            this.ThreeBtn.OnDisabledState.IconRightImage = null;
            this.ThreeBtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.ThreeBtn.onHoverState.BorderRadius = 1;
            this.ThreeBtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ThreeBtn.onHoverState.BorderThickness = 1;
            this.ThreeBtn.onHoverState.FillColor = System.Drawing.Color.Gold;
            this.ThreeBtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.ThreeBtn.onHoverState.IconLeftImage = null;
            this.ThreeBtn.onHoverState.IconRightImage = null;
            this.ThreeBtn.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.ThreeBtn.OnIdleState.BorderRadius = 1;
            this.ThreeBtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ThreeBtn.OnIdleState.BorderThickness = 1;
            this.ThreeBtn.OnIdleState.FillColor = System.Drawing.Color.Yellow;
            this.ThreeBtn.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.ThreeBtn.OnIdleState.IconLeftImage = null;
            this.ThreeBtn.OnIdleState.IconRightImage = null;
            this.ThreeBtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.ThreeBtn.OnPressedState.BorderRadius = 1;
            this.ThreeBtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.ThreeBtn.OnPressedState.BorderThickness = 1;
            this.ThreeBtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.ThreeBtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.ThreeBtn.OnPressedState.IconLeftImage = null;
            this.ThreeBtn.OnPressedState.IconRightImage = null;
            this.ThreeBtn.Size = new System.Drawing.Size(75, 75);
            this.ThreeBtn.TabIndex = 7;
            this.ThreeBtn.TabStop = false;
            this.ThreeBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.ThreeBtn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.ThreeBtn.TextMarginLeft = 0;
            this.ThreeBtn.TextPadding = new System.Windows.Forms.Padding(0);
            this.ThreeBtn.UseDefaultRadiusAndThickness = true;
            this.ThreeBtn.Click += new System.EventHandler(this.ThreeBtn_Click);
            // 
            // FourBtn
            // 
            this.FourBtn.AllowAnimations = true;
            this.FourBtn.AllowMouseEffects = true;
            this.FourBtn.AllowToggling = false;
            this.FourBtn.AnimationSpeed = 200;
            this.FourBtn.AutoGenerateColors = false;
            this.FourBtn.AutoRoundBorders = false;
            this.FourBtn.AutoSizeLeftIcon = true;
            this.FourBtn.AutoSizeRightIcon = true;
            this.FourBtn.BackColor = System.Drawing.Color.Transparent;
            this.FourBtn.BackColor1 = System.Drawing.Color.Yellow;
            this.FourBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("FourBtn.BackgroundImage")));
            this.FourBtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.FourBtn.ButtonText = "4";
            this.FourBtn.ButtonTextMarginLeft = 0;
            this.FourBtn.ColorContrastOnClick = 45;
            this.FourBtn.ColorContrastOnHover = 45;
            this.FourBtn.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges34.BottomLeft = true;
            borderEdges34.BottomRight = true;
            borderEdges34.TopLeft = true;
            borderEdges34.TopRight = true;
            this.FourBtn.CustomizableEdges = borderEdges34;
            this.FourBtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.FourBtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.FourBtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.FourBtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.FourBtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.FourBtn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FourBtn.ForeColor = System.Drawing.Color.Black;
            this.FourBtn.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FourBtn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.FourBtn.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.FourBtn.IconMarginLeft = 11;
            this.FourBtn.IconPadding = 10;
            this.FourBtn.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.FourBtn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.FourBtn.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.FourBtn.IconSize = 25;
            this.FourBtn.IdleBorderColor = System.Drawing.Color.White;
            this.FourBtn.IdleBorderRadius = 1;
            this.FourBtn.IdleBorderThickness = 1;
            this.FourBtn.IdleFillColor = System.Drawing.Color.Yellow;
            this.FourBtn.IdleIconLeftImage = null;
            this.FourBtn.IdleIconRightImage = null;
            this.FourBtn.IndicateFocus = false;
            this.FourBtn.Location = new System.Drawing.Point(69, 251);
            this.FourBtn.Name = "FourBtn";
            this.FourBtn.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.FourBtn.OnDisabledState.BorderRadius = 1;
            this.FourBtn.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.FourBtn.OnDisabledState.BorderThickness = 1;
            this.FourBtn.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.FourBtn.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.FourBtn.OnDisabledState.IconLeftImage = null;
            this.FourBtn.OnDisabledState.IconRightImage = null;
            this.FourBtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.FourBtn.onHoverState.BorderRadius = 1;
            this.FourBtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.FourBtn.onHoverState.BorderThickness = 1;
            this.FourBtn.onHoverState.FillColor = System.Drawing.Color.Gold;
            this.FourBtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.FourBtn.onHoverState.IconLeftImage = null;
            this.FourBtn.onHoverState.IconRightImage = null;
            this.FourBtn.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.FourBtn.OnIdleState.BorderRadius = 1;
            this.FourBtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.FourBtn.OnIdleState.BorderThickness = 1;
            this.FourBtn.OnIdleState.FillColor = System.Drawing.Color.Yellow;
            this.FourBtn.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.FourBtn.OnIdleState.IconLeftImage = null;
            this.FourBtn.OnIdleState.IconRightImage = null;
            this.FourBtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.FourBtn.OnPressedState.BorderRadius = 1;
            this.FourBtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.FourBtn.OnPressedState.BorderThickness = 1;
            this.FourBtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.FourBtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.FourBtn.OnPressedState.IconLeftImage = null;
            this.FourBtn.OnPressedState.IconRightImage = null;
            this.FourBtn.Size = new System.Drawing.Size(75, 75);
            this.FourBtn.TabIndex = 6;
            this.FourBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.FourBtn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.FourBtn.TextMarginLeft = 0;
            this.FourBtn.TextPadding = new System.Windows.Forms.Padding(0);
            this.FourBtn.UseDefaultRadiusAndThickness = true;
            this.FourBtn.Click += new System.EventHandler(this.FourBtn_Click);
            // 
            // FiveBtn
            // 
            this.FiveBtn.AllowAnimations = true;
            this.FiveBtn.AllowMouseEffects = true;
            this.FiveBtn.AllowToggling = false;
            this.FiveBtn.AnimationSpeed = 200;
            this.FiveBtn.AutoGenerateColors = false;
            this.FiveBtn.AutoRoundBorders = false;
            this.FiveBtn.AutoSizeLeftIcon = true;
            this.FiveBtn.AutoSizeRightIcon = true;
            this.FiveBtn.BackColor = System.Drawing.Color.Transparent;
            this.FiveBtn.BackColor1 = System.Drawing.Color.Yellow;
            this.FiveBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("FiveBtn.BackgroundImage")));
            this.FiveBtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.FiveBtn.ButtonText = "5";
            this.FiveBtn.ButtonTextMarginLeft = 0;
            this.FiveBtn.ColorContrastOnClick = 45;
            this.FiveBtn.ColorContrastOnHover = 45;
            this.FiveBtn.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges35.BottomLeft = true;
            borderEdges35.BottomRight = true;
            borderEdges35.TopLeft = true;
            borderEdges35.TopRight = true;
            this.FiveBtn.CustomizableEdges = borderEdges35;
            this.FiveBtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.FiveBtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.FiveBtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.FiveBtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.FiveBtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.FiveBtn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FiveBtn.ForeColor = System.Drawing.Color.Black;
            this.FiveBtn.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.FiveBtn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.FiveBtn.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.FiveBtn.IconMarginLeft = 11;
            this.FiveBtn.IconPadding = 10;
            this.FiveBtn.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.FiveBtn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.FiveBtn.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.FiveBtn.IconSize = 25;
            this.FiveBtn.IdleBorderColor = System.Drawing.Color.White;
            this.FiveBtn.IdleBorderRadius = 1;
            this.FiveBtn.IdleBorderThickness = 1;
            this.FiveBtn.IdleFillColor = System.Drawing.Color.Yellow;
            this.FiveBtn.IdleIconLeftImage = null;
            this.FiveBtn.IdleIconRightImage = null;
            this.FiveBtn.IndicateFocus = false;
            this.FiveBtn.Location = new System.Drawing.Point(168, 252);
            this.FiveBtn.Name = "FiveBtn";
            this.FiveBtn.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.FiveBtn.OnDisabledState.BorderRadius = 1;
            this.FiveBtn.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.FiveBtn.OnDisabledState.BorderThickness = 1;
            this.FiveBtn.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.FiveBtn.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.FiveBtn.OnDisabledState.IconLeftImage = null;
            this.FiveBtn.OnDisabledState.IconRightImage = null;
            this.FiveBtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.FiveBtn.onHoverState.BorderRadius = 1;
            this.FiveBtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.FiveBtn.onHoverState.BorderThickness = 1;
            this.FiveBtn.onHoverState.FillColor = System.Drawing.Color.Gold;
            this.FiveBtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.FiveBtn.onHoverState.IconLeftImage = null;
            this.FiveBtn.onHoverState.IconRightImage = null;
            this.FiveBtn.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.FiveBtn.OnIdleState.BorderRadius = 1;
            this.FiveBtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.FiveBtn.OnIdleState.BorderThickness = 1;
            this.FiveBtn.OnIdleState.FillColor = System.Drawing.Color.Yellow;
            this.FiveBtn.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.FiveBtn.OnIdleState.IconLeftImage = null;
            this.FiveBtn.OnIdleState.IconRightImage = null;
            this.FiveBtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.FiveBtn.OnPressedState.BorderRadius = 1;
            this.FiveBtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.FiveBtn.OnPressedState.BorderThickness = 1;
            this.FiveBtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.FiveBtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.FiveBtn.OnPressedState.IconLeftImage = null;
            this.FiveBtn.OnPressedState.IconRightImage = null;
            this.FiveBtn.Size = new System.Drawing.Size(75, 75);
            this.FiveBtn.TabIndex = 5;
            this.FiveBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.FiveBtn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.FiveBtn.TextMarginLeft = 0;
            this.FiveBtn.TextPadding = new System.Windows.Forms.Padding(0);
            this.FiveBtn.UseDefaultRadiusAndThickness = true;
            this.FiveBtn.Click += new System.EventHandler(this.FiveBtn_Click);
            // 
            // NineBtn
            // 
            this.NineBtn.AllowAnimations = true;
            this.NineBtn.AllowMouseEffects = true;
            this.NineBtn.AllowToggling = false;
            this.NineBtn.AnimationSpeed = 200;
            this.NineBtn.AutoGenerateColors = false;
            this.NineBtn.AutoRoundBorders = false;
            this.NineBtn.AutoSizeLeftIcon = true;
            this.NineBtn.AutoSizeRightIcon = true;
            this.NineBtn.BackColor = System.Drawing.Color.Transparent;
            this.NineBtn.BackColor1 = System.Drawing.Color.Yellow;
            this.NineBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("NineBtn.BackgroundImage")));
            this.NineBtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.NineBtn.ButtonText = "9";
            this.NineBtn.ButtonTextMarginLeft = 0;
            this.NineBtn.ColorContrastOnClick = 45;
            this.NineBtn.ColorContrastOnHover = 45;
            this.NineBtn.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges36.BottomLeft = true;
            borderEdges36.BottomRight = true;
            borderEdges36.TopLeft = true;
            borderEdges36.TopRight = true;
            this.NineBtn.CustomizableEdges = borderEdges36;
            this.NineBtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.NineBtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.NineBtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.NineBtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.NineBtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.NineBtn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NineBtn.ForeColor = System.Drawing.Color.Black;
            this.NineBtn.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.NineBtn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.NineBtn.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.NineBtn.IconMarginLeft = 11;
            this.NineBtn.IconPadding = 10;
            this.NineBtn.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.NineBtn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.NineBtn.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.NineBtn.IconSize = 25;
            this.NineBtn.IdleBorderColor = System.Drawing.Color.White;
            this.NineBtn.IdleBorderRadius = 1;
            this.NineBtn.IdleBorderThickness = 1;
            this.NineBtn.IdleFillColor = System.Drawing.Color.Yellow;
            this.NineBtn.IdleIconLeftImage = null;
            this.NineBtn.IdleIconRightImage = null;
            this.NineBtn.IndicateFocus = false;
            this.NineBtn.Location = new System.Drawing.Point(264, 162);
            this.NineBtn.Name = "NineBtn";
            this.NineBtn.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.NineBtn.OnDisabledState.BorderRadius = 1;
            this.NineBtn.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.NineBtn.OnDisabledState.BorderThickness = 1;
            this.NineBtn.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.NineBtn.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.NineBtn.OnDisabledState.IconLeftImage = null;
            this.NineBtn.OnDisabledState.IconRightImage = null;
            this.NineBtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.NineBtn.onHoverState.BorderRadius = 1;
            this.NineBtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.NineBtn.onHoverState.BorderThickness = 1;
            this.NineBtn.onHoverState.FillColor = System.Drawing.Color.Gold;
            this.NineBtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.NineBtn.onHoverState.IconLeftImage = null;
            this.NineBtn.onHoverState.IconRightImage = null;
            this.NineBtn.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.NineBtn.OnIdleState.BorderRadius = 1;
            this.NineBtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.NineBtn.OnIdleState.BorderThickness = 1;
            this.NineBtn.OnIdleState.FillColor = System.Drawing.Color.Yellow;
            this.NineBtn.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.NineBtn.OnIdleState.IconLeftImage = null;
            this.NineBtn.OnIdleState.IconRightImage = null;
            this.NineBtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.NineBtn.OnPressedState.BorderRadius = 1;
            this.NineBtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.NineBtn.OnPressedState.BorderThickness = 1;
            this.NineBtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.NineBtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.NineBtn.OnPressedState.IconLeftImage = null;
            this.NineBtn.OnPressedState.IconRightImage = null;
            this.NineBtn.Size = new System.Drawing.Size(75, 75);
            this.NineBtn.TabIndex = 3;
            this.NineBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.NineBtn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.NineBtn.TextMarginLeft = 0;
            this.NineBtn.TextPadding = new System.Windows.Forms.Padding(0);
            this.NineBtn.UseDefaultRadiusAndThickness = true;
            this.NineBtn.Click += new System.EventHandler(this.NineBtn_Click);
            // 
            // EightBtn
            // 
            this.EightBtn.AllowAnimations = true;
            this.EightBtn.AllowMouseEffects = true;
            this.EightBtn.AllowToggling = false;
            this.EightBtn.AnimationSpeed = 200;
            this.EightBtn.AutoGenerateColors = false;
            this.EightBtn.AutoRoundBorders = false;
            this.EightBtn.AutoSizeLeftIcon = true;
            this.EightBtn.AutoSizeRightIcon = true;
            this.EightBtn.BackColor = System.Drawing.Color.Transparent;
            this.EightBtn.BackColor1 = System.Drawing.Color.Yellow;
            this.EightBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("EightBtn.BackgroundImage")));
            this.EightBtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.EightBtn.ButtonText = "8";
            this.EightBtn.ButtonTextMarginLeft = 0;
            this.EightBtn.ColorContrastOnClick = 45;
            this.EightBtn.ColorContrastOnHover = 45;
            this.EightBtn.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges37.BottomLeft = true;
            borderEdges37.BottomRight = true;
            borderEdges37.TopLeft = true;
            borderEdges37.TopRight = true;
            this.EightBtn.CustomizableEdges = borderEdges37;
            this.EightBtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.EightBtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.EightBtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.EightBtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.EightBtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.EightBtn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EightBtn.ForeColor = System.Drawing.Color.Black;
            this.EightBtn.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.EightBtn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.EightBtn.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.EightBtn.IconMarginLeft = 11;
            this.EightBtn.IconPadding = 10;
            this.EightBtn.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.EightBtn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.EightBtn.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.EightBtn.IconSize = 25;
            this.EightBtn.IdleBorderColor = System.Drawing.Color.White;
            this.EightBtn.IdleBorderRadius = 1;
            this.EightBtn.IdleBorderThickness = 1;
            this.EightBtn.IdleFillColor = System.Drawing.Color.Yellow;
            this.EightBtn.IdleIconLeftImage = null;
            this.EightBtn.IdleIconRightImage = null;
            this.EightBtn.IndicateFocus = false;
            this.EightBtn.Location = new System.Drawing.Point(168, 161);
            this.EightBtn.Name = "EightBtn";
            this.EightBtn.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.EightBtn.OnDisabledState.BorderRadius = 1;
            this.EightBtn.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.EightBtn.OnDisabledState.BorderThickness = 1;
            this.EightBtn.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.EightBtn.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.EightBtn.OnDisabledState.IconLeftImage = null;
            this.EightBtn.OnDisabledState.IconRightImage = null;
            this.EightBtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.EightBtn.onHoverState.BorderRadius = 1;
            this.EightBtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.EightBtn.onHoverState.BorderThickness = 1;
            this.EightBtn.onHoverState.FillColor = System.Drawing.Color.Gold;
            this.EightBtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.EightBtn.onHoverState.IconLeftImage = null;
            this.EightBtn.onHoverState.IconRightImage = null;
            this.EightBtn.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.EightBtn.OnIdleState.BorderRadius = 1;
            this.EightBtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.EightBtn.OnIdleState.BorderThickness = 1;
            this.EightBtn.OnIdleState.FillColor = System.Drawing.Color.Yellow;
            this.EightBtn.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.EightBtn.OnIdleState.IconLeftImage = null;
            this.EightBtn.OnIdleState.IconRightImage = null;
            this.EightBtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.EightBtn.OnPressedState.BorderRadius = 1;
            this.EightBtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.EightBtn.OnPressedState.BorderThickness = 1;
            this.EightBtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.EightBtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.EightBtn.OnPressedState.IconLeftImage = null;
            this.EightBtn.OnPressedState.IconRightImage = null;
            this.EightBtn.Size = new System.Drawing.Size(75, 75);
            this.EightBtn.TabIndex = 2;
            this.EightBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.EightBtn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.EightBtn.TextMarginLeft = 0;
            this.EightBtn.TextPadding = new System.Windows.Forms.Padding(0);
            this.EightBtn.UseDefaultRadiusAndThickness = true;
            this.EightBtn.Click += new System.EventHandler(this.EightBtn_Click);
            // 
            // SevenBtn
            // 
            this.SevenBtn.AllowAnimations = true;
            this.SevenBtn.AllowMouseEffects = true;
            this.SevenBtn.AllowToggling = false;
            this.SevenBtn.AnimationSpeed = 200;
            this.SevenBtn.AutoGenerateColors = false;
            this.SevenBtn.AutoRoundBorders = false;
            this.SevenBtn.AutoSizeLeftIcon = true;
            this.SevenBtn.AutoSizeRightIcon = true;
            this.SevenBtn.BackColor = System.Drawing.Color.Transparent;
            this.SevenBtn.BackColor1 = System.Drawing.Color.Yellow;
            this.SevenBtn.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("SevenBtn.BackgroundImage")));
            this.SevenBtn.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.SevenBtn.ButtonText = "7";
            this.SevenBtn.ButtonTextMarginLeft = 0;
            this.SevenBtn.ColorContrastOnClick = 45;
            this.SevenBtn.ColorContrastOnHover = 45;
            this.SevenBtn.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges38.BottomLeft = true;
            borderEdges38.BottomRight = true;
            borderEdges38.TopLeft = true;
            borderEdges38.TopRight = true;
            this.SevenBtn.CustomizableEdges = borderEdges38;
            this.SevenBtn.DialogResult = System.Windows.Forms.DialogResult.None;
            this.SevenBtn.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.SevenBtn.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.SevenBtn.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.SevenBtn.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.SevenBtn.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SevenBtn.ForeColor = System.Drawing.Color.Black;
            this.SevenBtn.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.SevenBtn.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.SevenBtn.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.SevenBtn.IconMarginLeft = 11;
            this.SevenBtn.IconPadding = 10;
            this.SevenBtn.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.SevenBtn.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.SevenBtn.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.SevenBtn.IconSize = 25;
            this.SevenBtn.IdleBorderColor = System.Drawing.Color.White;
            this.SevenBtn.IdleBorderRadius = 1;
            this.SevenBtn.IdleBorderThickness = 1;
            this.SevenBtn.IdleFillColor = System.Drawing.Color.Yellow;
            this.SevenBtn.IdleIconLeftImage = null;
            this.SevenBtn.IdleIconRightImage = null;
            this.SevenBtn.IndicateFocus = false;
            this.SevenBtn.Location = new System.Drawing.Point(69, 161);
            this.SevenBtn.Name = "SevenBtn";
            this.SevenBtn.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.SevenBtn.OnDisabledState.BorderRadius = 1;
            this.SevenBtn.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.SevenBtn.OnDisabledState.BorderThickness = 1;
            this.SevenBtn.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.SevenBtn.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.SevenBtn.OnDisabledState.IconLeftImage = null;
            this.SevenBtn.OnDisabledState.IconRightImage = null;
            this.SevenBtn.onHoverState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.SevenBtn.onHoverState.BorderRadius = 1;
            this.SevenBtn.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.SevenBtn.onHoverState.BorderThickness = 1;
            this.SevenBtn.onHoverState.FillColor = System.Drawing.Color.Gold;
            this.SevenBtn.onHoverState.ForeColor = System.Drawing.Color.White;
            this.SevenBtn.onHoverState.IconLeftImage = null;
            this.SevenBtn.onHoverState.IconRightImage = null;
            this.SevenBtn.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.SevenBtn.OnIdleState.BorderRadius = 1;
            this.SevenBtn.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.SevenBtn.OnIdleState.BorderThickness = 1;
            this.SevenBtn.OnIdleState.FillColor = System.Drawing.Color.Yellow;
            this.SevenBtn.OnIdleState.ForeColor = System.Drawing.Color.Black;
            this.SevenBtn.OnIdleState.IconLeftImage = null;
            this.SevenBtn.OnIdleState.IconRightImage = null;
            this.SevenBtn.OnPressedState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.SevenBtn.OnPressedState.BorderRadius = 1;
            this.SevenBtn.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.SevenBtn.OnPressedState.BorderThickness = 1;
            this.SevenBtn.OnPressedState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(40)))), ((int)(((byte)(96)))), ((int)(((byte)(144)))));
            this.SevenBtn.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.SevenBtn.OnPressedState.IconLeftImage = null;
            this.SevenBtn.OnPressedState.IconRightImage = null;
            this.SevenBtn.Size = new System.Drawing.Size(75, 75);
            this.SevenBtn.TabIndex = 1;
            this.SevenBtn.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.SevenBtn.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.SevenBtn.TextMarginLeft = 0;
            this.SevenBtn.TextPadding = new System.Windows.Forms.Padding(0);
            this.SevenBtn.UseDefaultRadiusAndThickness = true;
            this.SevenBtn.Click += new System.EventHandler(this.SevenBtn_Click);
            // 
            // TxtBox
            // 
            this.TxtBox.AcceptsReturn = false;
            this.TxtBox.AcceptsTab = false;
            this.TxtBox.AnimationSpeed = 200;
            this.TxtBox.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.TxtBox.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.TxtBox.BackColor = System.Drawing.Color.White;
            this.TxtBox.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("TxtBox.BackgroundImage")));
            this.TxtBox.BorderColorActive = System.Drawing.Color.DodgerBlue;
            this.TxtBox.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.TxtBox.BorderColorHover = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            this.TxtBox.BorderColorIdle = System.Drawing.Color.Silver;
            this.TxtBox.BorderRadius = 1;
            this.TxtBox.BorderThickness = 1;
            this.TxtBox.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.TxtBox.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtBox.DefaultFont = new System.Drawing.Font("Century Gothic", 16.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxtBox.DefaultText = "";
            this.TxtBox.FillColor = System.Drawing.Color.White;
            this.TxtBox.ForeColor = System.Drawing.Color.Black;
            this.TxtBox.HideSelection = true;
            this.TxtBox.IconLeft = null;
            this.TxtBox.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtBox.IconPadding = 10;
            this.TxtBox.IconRight = null;
            this.TxtBox.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.TxtBox.Lines = new string[0];
            this.TxtBox.Location = new System.Drawing.Point(69, 57);
            this.TxtBox.MaxLength = 32767;
            this.TxtBox.MinimumSize = new System.Drawing.Size(1, 1);
            this.TxtBox.Modified = false;
            this.TxtBox.Multiline = false;
            this.TxtBox.Name = "TxtBox";
            stateProperties77.BorderColor = System.Drawing.Color.DodgerBlue;
            stateProperties77.FillColor = System.Drawing.Color.Empty;
            stateProperties77.ForeColor = System.Drawing.Color.Empty;
            stateProperties77.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TxtBox.OnActiveState = stateProperties77;
            stateProperties78.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            stateProperties78.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(240)))), ((int)(((byte)(240)))), ((int)(((byte)(240)))));
            stateProperties78.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(109)))), ((int)(((byte)(109)))), ((int)(((byte)(109)))));
            stateProperties78.PlaceholderForeColor = System.Drawing.Color.DarkGray;
            this.TxtBox.OnDisabledState = stateProperties78;
            stateProperties79.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(105)))), ((int)(((byte)(181)))), ((int)(((byte)(255)))));
            stateProperties79.FillColor = System.Drawing.Color.Empty;
            stateProperties79.ForeColor = System.Drawing.Color.Empty;
            stateProperties79.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TxtBox.OnHoverState = stateProperties79;
            stateProperties80.BorderColor = System.Drawing.Color.Silver;
            stateProperties80.FillColor = System.Drawing.Color.White;
            stateProperties80.ForeColor = System.Drawing.Color.Black;
            stateProperties80.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.TxtBox.OnIdleState = stateProperties80;
            this.TxtBox.Padding = new System.Windows.Forms.Padding(3);
            this.TxtBox.PasswordChar = '\0';
            this.TxtBox.PlaceholderForeColor = System.Drawing.Color.Black;
            this.TxtBox.PlaceholderText = "";
            this.TxtBox.ReadOnly = false;
            this.TxtBox.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.TxtBox.SelectedText = "";
            this.TxtBox.SelectionLength = 0;
            this.TxtBox.SelectionStart = 0;
            this.TxtBox.ShortcutsEnabled = true;
            this.TxtBox.Size = new System.Drawing.Size(602, 54);
            this.TxtBox.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.TxtBox.TabIndex = 0;
            this.TxtBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.TxtBox.TextMarginBottom = 0;
            this.TxtBox.TextMarginLeft = 3;
            this.TxtBox.TextMarginTop = 0;
            this.TxtBox.TextPlaceholder = "";
            this.TxtBox.UseSystemPasswordChar = false;
            this.TxtBox.WordWrap = true;
            // 
            // panel3
            // 
            this.panel3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(31)))), ((int)(((byte)(31)))), ((int)(((byte)(31)))));
            this.panel3.Controls.Add(this.bunifuImageButton8);
            this.panel3.Controls.Add(this.bunifuImageButton7);
            this.panel3.Controls.Add(this.bunifuImageButton6);
            this.panel3.Controls.Add(this.pictureBox2);
            this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel3.Location = new System.Drawing.Point(359, 0);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(716, 49);
            this.panel3.TabIndex = 1;
            this.panel3.Paint += new System.Windows.Forms.PaintEventHandler(this.panel3_Paint);
            // 
            // bunifuImageButton8
            // 
            this.bunifuImageButton8.ActiveImage = null;
            this.bunifuImageButton8.AllowAnimations = true;
            this.bunifuImageButton8.AllowBuffering = false;
            this.bunifuImageButton8.AllowToggling = false;
            this.bunifuImageButton8.AllowZooming = false;
            this.bunifuImageButton8.AllowZoomingOnFocus = false;
            this.bunifuImageButton8.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton8.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuImageButton8.Dock = System.Windows.Forms.DockStyle.Right;
            this.bunifuImageButton8.ErrorImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton8.ErrorImage")));
            this.bunifuImageButton8.FadeWhenInactive = false;
            this.bunifuImageButton8.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.bunifuImageButton8.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton8.Image")));
            this.bunifuImageButton8.ImageActive = null;
            this.bunifuImageButton8.ImageLocation = null;
            this.bunifuImageButton8.ImageMargin = 1;
            this.bunifuImageButton8.ImageSize = new System.Drawing.Size(89, 48);
            this.bunifuImageButton8.ImageZoomSize = new System.Drawing.Size(90, 49);
            this.bunifuImageButton8.InitialImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton8.InitialImage")));
            this.bunifuImageButton8.Location = new System.Drawing.Point(446, 0);
            this.bunifuImageButton8.Name = "bunifuImageButton8";
            this.bunifuImageButton8.Rotation = 0;
            this.bunifuImageButton8.ShowActiveImage = true;
            this.bunifuImageButton8.ShowCursorChanges = true;
            this.bunifuImageButton8.ShowImageBorders = false;
            this.bunifuImageButton8.ShowSizeMarkers = false;
            this.bunifuImageButton8.Size = new System.Drawing.Size(90, 49);
            this.bunifuImageButton8.TabIndex = 12;
            this.bunifuImageButton8.ToolTipText = "";
            this.bunifuImageButton8.WaitOnLoad = false;
            this.bunifuImageButton8.Zoom = 1;
            this.bunifuImageButton8.ZoomSpeed = 10;
            this.bunifuImageButton8.Click += new System.EventHandler(this.bunifuImageButton8_Click);
            // 
            // bunifuImageButton7
            // 
            this.bunifuImageButton7.ActiveImage = null;
            this.bunifuImageButton7.AllowAnimations = true;
            this.bunifuImageButton7.AllowBuffering = false;
            this.bunifuImageButton7.AllowToggling = false;
            this.bunifuImageButton7.AllowZooming = false;
            this.bunifuImageButton7.AllowZoomingOnFocus = false;
            this.bunifuImageButton7.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton7.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuImageButton7.Dock = System.Windows.Forms.DockStyle.Right;
            this.bunifuImageButton7.ErrorImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton7.ErrorImage")));
            this.bunifuImageButton7.FadeWhenInactive = false;
            this.bunifuImageButton7.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.bunifuImageButton7.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton7.Image")));
            this.bunifuImageButton7.ImageActive = null;
            this.bunifuImageButton7.ImageLocation = null;
            this.bunifuImageButton7.ImageMargin = 0;
            this.bunifuImageButton7.ImageSize = new System.Drawing.Size(90, 49);
            this.bunifuImageButton7.ImageZoomSize = new System.Drawing.Size(90, 49);
            this.bunifuImageButton7.InitialImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton7.InitialImage")));
            this.bunifuImageButton7.Location = new System.Drawing.Point(536, 0);
            this.bunifuImageButton7.Name = "bunifuImageButton7";
            this.bunifuImageButton7.Rotation = 0;
            this.bunifuImageButton7.ShowActiveImage = true;
            this.bunifuImageButton7.ShowCursorChanges = true;
            this.bunifuImageButton7.ShowImageBorders = false;
            this.bunifuImageButton7.ShowSizeMarkers = false;
            this.bunifuImageButton7.Size = new System.Drawing.Size(90, 49);
            this.bunifuImageButton7.TabIndex = 11;
            this.bunifuImageButton7.ToolTipText = "";
            this.bunifuImageButton7.WaitOnLoad = false;
            this.bunifuImageButton7.Zoom = 0;
            this.bunifuImageButton7.ZoomSpeed = 10;
            this.bunifuImageButton7.Click += new System.EventHandler(this.bunifuImageButton7_Click);
            // 
            // bunifuImageButton6
            // 
            this.bunifuImageButton6.ActiveImage = null;
            this.bunifuImageButton6.AllowAnimations = true;
            this.bunifuImageButton6.AllowBuffering = false;
            this.bunifuImageButton6.AllowToggling = false;
            this.bunifuImageButton6.AllowZooming = false;
            this.bunifuImageButton6.AllowZoomingOnFocus = false;
            this.bunifuImageButton6.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton6.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuImageButton6.Dock = System.Windows.Forms.DockStyle.Right;
            this.bunifuImageButton6.ErrorImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton6.ErrorImage")));
            this.bunifuImageButton6.FadeWhenInactive = false;
            this.bunifuImageButton6.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.bunifuImageButton6.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton6.Image")));
            this.bunifuImageButton6.ImageActive = null;
            this.bunifuImageButton6.ImageLocation = null;
            this.bunifuImageButton6.ImageMargin = 0;
            this.bunifuImageButton6.ImageSize = new System.Drawing.Size(90, 49);
            this.bunifuImageButton6.ImageZoomSize = new System.Drawing.Size(90, 49);
            this.bunifuImageButton6.InitialImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton6.InitialImage")));
            this.bunifuImageButton6.Location = new System.Drawing.Point(626, 0);
            this.bunifuImageButton6.Name = "bunifuImageButton6";
            this.bunifuImageButton6.Rotation = 0;
            this.bunifuImageButton6.ShowActiveImage = true;
            this.bunifuImageButton6.ShowCursorChanges = true;
            this.bunifuImageButton6.ShowImageBorders = false;
            this.bunifuImageButton6.ShowSizeMarkers = false;
            this.bunifuImageButton6.Size = new System.Drawing.Size(90, 49);
            this.bunifuImageButton6.TabIndex = 10;
            this.bunifuImageButton6.ToolTipText = "";
            this.bunifuImageButton6.WaitOnLoad = false;
            this.bunifuImageButton6.Zoom = 0;
            this.bunifuImageButton6.ZoomSpeed = 10;
            this.bunifuImageButton6.Click += new System.EventHandler(this.bunifuImageButton6_Click);
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = global::APK_Konversi.Properties.Resources._20230828_214418_0000_removebg_preview;
            this.pictureBox2.Location = new System.Drawing.Point(-31, -10);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(162, 73);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 9;
            this.pictureBox2.TabStop = false;
            // 
            // panel2
            // 
            this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel2.Controls.Add(this.label25);
            this.panel2.Controls.Add(this.bunifuImageButton11);
            this.panel2.Controls.Add(this.label24);
            this.panel2.Controls.Add(this.bunifuImageButton10);
            this.panel2.Controls.Add(this.label23);
            this.panel2.Controls.Add(this.bunifuImageButton9);
            this.panel2.Controls.Add(this.label13);
            this.panel2.Controls.Add(this.label12);
            this.panel2.Controls.Add(this.label11);
            this.panel2.Controls.Add(this.label10);
            this.panel2.Controls.Add(this.label9);
            this.panel2.Controls.Add(this.bunifuImageButton5);
            this.panel2.Controls.Add(this.bunifuImageButton4);
            this.panel2.Controls.Add(this.bunifuImageButton3);
            this.panel2.Controls.Add(this.bunifuImageButton2);
            this.panel2.Controls.Add(this.bunifuImageButton1);
            this.panel2.Controls.Add(this.panel4);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.MaximumSize = new System.Drawing.Size(359, 622);
            this.panel2.MinimumSize = new System.Drawing.Size(84, 622);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(359, 622);
            this.panel2.TabIndex = 0;
            this.panel2.Paint += new System.Windows.Forms.PaintEventHandler(this.panel2_Paint);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label25.ForeColor = System.Drawing.Color.White;
            this.label25.Location = new System.Drawing.Point(234, 582);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(90, 19);
            this.label25.TabIndex = 17;
            this.label25.Text = "Kalkulator";
            // 
            // bunifuImageButton11
            // 
            this.bunifuImageButton11.ActiveImage = null;
            this.bunifuImageButton11.AllowAnimations = true;
            this.bunifuImageButton11.AllowBuffering = false;
            this.bunifuImageButton11.AllowToggling = false;
            this.bunifuImageButton11.AllowZooming = false;
            this.bunifuImageButton11.AllowZoomingOnFocus = false;
            this.bunifuImageButton11.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton11.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuImageButton11.ErrorImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton11.ErrorImage")));
            this.bunifuImageButton11.FadeWhenInactive = false;
            this.bunifuImageButton11.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.bunifuImageButton11.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton11.Image")));
            this.bunifuImageButton11.ImageActive = null;
            this.bunifuImageButton11.ImageLocation = null;
            this.bunifuImageButton11.ImageMargin = 50;
            this.bunifuImageButton11.ImageSize = new System.Drawing.Size(90, 71);
            this.bunifuImageButton11.ImageZoomSize = new System.Drawing.Size(140, 121);
            this.bunifuImageButton11.InitialImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton11.InitialImage")));
            this.bunifuImageButton11.Location = new System.Drawing.Point(209, 460);
            this.bunifuImageButton11.Name = "bunifuImageButton11";
            this.bunifuImageButton11.Rotation = 0;
            this.bunifuImageButton11.ShowActiveImage = true;
            this.bunifuImageButton11.ShowCursorChanges = true;
            this.bunifuImageButton11.ShowImageBorders = false;
            this.bunifuImageButton11.ShowSizeMarkers = false;
            this.bunifuImageButton11.Size = new System.Drawing.Size(140, 121);
            this.bunifuImageButton11.TabIndex = 19;
            this.bunifuImageButton11.ToolTipText = "";
            this.bunifuImageButton11.WaitOnLoad = false;
            this.bunifuImageButton11.Zoom = 50;
            this.bunifuImageButton11.ZoomSpeed = 10;
            this.bunifuImageButton11.Click += new System.EventHandler(this.bunifuImageButton11_Click);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label24.ForeColor = System.Drawing.Color.White;
            this.label24.Location = new System.Drawing.Point(104, 581);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(47, 19);
            this.label24.TabIndex = 18;
            this.label24.Text = "Data";
            // 
            // bunifuImageButton10
            // 
            this.bunifuImageButton10.ActiveImage = null;
            this.bunifuImageButton10.AllowAnimations = true;
            this.bunifuImageButton10.AllowBuffering = false;
            this.bunifuImageButton10.AllowToggling = false;
            this.bunifuImageButton10.AllowZooming = false;
            this.bunifuImageButton10.AllowZoomingOnFocus = false;
            this.bunifuImageButton10.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton10.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuImageButton10.ErrorImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton10.ErrorImage")));
            this.bunifuImageButton10.FadeWhenInactive = false;
            this.bunifuImageButton10.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.bunifuImageButton10.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton10.Image")));
            this.bunifuImageButton10.ImageActive = null;
            this.bunifuImageButton10.ImageLocation = null;
            this.bunifuImageButton10.ImageMargin = 65;
            this.bunifuImageButton10.ImageSize = new System.Drawing.Size(80, 72);
            this.bunifuImageButton10.ImageZoomSize = new System.Drawing.Size(145, 137);
            this.bunifuImageButton10.InitialImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton10.InitialImage")));
            this.bunifuImageButton10.Location = new System.Drawing.Point(53, 451);
            this.bunifuImageButton10.Name = "bunifuImageButton10";
            this.bunifuImageButton10.Rotation = 0;
            this.bunifuImageButton10.ShowActiveImage = true;
            this.bunifuImageButton10.ShowCursorChanges = true;
            this.bunifuImageButton10.ShowImageBorders = false;
            this.bunifuImageButton10.ShowSizeMarkers = false;
            this.bunifuImageButton10.Size = new System.Drawing.Size(145, 137);
            this.bunifuImageButton10.TabIndex = 17;
            this.bunifuImageButton10.ToolTipText = "";
            this.bunifuImageButton10.WaitOnLoad = false;
            this.bunifuImageButton10.Zoom = 65;
            this.bunifuImageButton10.ZoomSpeed = 10;
            this.bunifuImageButton10.Click += new System.EventHandler(this.bunifuImageButton10_Click);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label23.ForeColor = System.Drawing.Color.White;
            this.label23.Location = new System.Drawing.Point(253, 439);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(49, 19);
            this.label23.TabIndex = 16;
            this.label23.Text = "Area";
            // 
            // bunifuImageButton9
            // 
            this.bunifuImageButton9.ActiveImage = null;
            this.bunifuImageButton9.AllowAnimations = true;
            this.bunifuImageButton9.AllowBuffering = false;
            this.bunifuImageButton9.AllowToggling = false;
            this.bunifuImageButton9.AllowZooming = false;
            this.bunifuImageButton9.AllowZoomingOnFocus = false;
            this.bunifuImageButton9.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton9.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuImageButton9.ErrorImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton9.ErrorImage")));
            this.bunifuImageButton9.FadeWhenInactive = false;
            this.bunifuImageButton9.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.bunifuImageButton9.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton9.Image")));
            this.bunifuImageButton9.ImageActive = null;
            this.bunifuImageButton9.ImageLocation = null;
            this.bunifuImageButton9.ImageMargin = 50;
            this.bunifuImageButton9.ImageSize = new System.Drawing.Size(78, 72);
            this.bunifuImageButton9.ImageZoomSize = new System.Drawing.Size(128, 122);
            this.bunifuImageButton9.InitialImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton9.InitialImage")));
            this.bunifuImageButton9.Location = new System.Drawing.Point(212, 333);
            this.bunifuImageButton9.Name = "bunifuImageButton9";
            this.bunifuImageButton9.Rotation = 0;
            this.bunifuImageButton9.ShowActiveImage = true;
            this.bunifuImageButton9.ShowCursorChanges = true;
            this.bunifuImageButton9.ShowImageBorders = false;
            this.bunifuImageButton9.ShowSizeMarkers = false;
            this.bunifuImageButton9.Size = new System.Drawing.Size(128, 122);
            this.bunifuImageButton9.TabIndex = 15;
            this.bunifuImageButton9.ToolTipText = "";
            this.bunifuImageButton9.WaitOnLoad = false;
            this.bunifuImageButton9.Zoom = 50;
            this.bunifuImageButton9.ZoomSpeed = 10;
            this.bunifuImageButton9.Click += new System.EventHandler(this.bunifuImageButton9_Click);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label13.ForeColor = System.Drawing.Color.White;
            this.label13.Location = new System.Drawing.Point(97, 430);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(73, 19);
            this.label13.TabIndex = 14;
            this.label13.Text = "Volume";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label12.ForeColor = System.Drawing.Color.White;
            this.label12.Location = new System.Drawing.Point(246, 316);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(59, 19);
            this.label12.TabIndex = 13;
            this.label12.Text = "Waktu";
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label11.ForeColor = System.Drawing.Color.White;
            this.label11.Location = new System.Drawing.Point(87, 312);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(76, 19);
            this.label11.TabIndex = 12;
            this.label11.Text = "Panjang";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.White;
            this.label10.Location = new System.Drawing.Point(246, 174);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(48, 19);
            this.label10.TabIndex = 11;
            this.label10.Text = "Suhu";
            this.label10.Click += new System.EventHandler(this.label10_Click);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Century Gothic", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.ForeColor = System.Drawing.Color.White;
            this.label9.Location = new System.Drawing.Point(98, 174);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(62, 19);
            this.label9.TabIndex = 10;
            this.label9.Text = "Massa";
            // 
            // bunifuImageButton5
            // 
            this.bunifuImageButton5.ActiveImage = null;
            this.bunifuImageButton5.AllowAnimations = true;
            this.bunifuImageButton5.AllowBuffering = false;
            this.bunifuImageButton5.AllowToggling = false;
            this.bunifuImageButton5.AllowZooming = false;
            this.bunifuImageButton5.AllowZoomingOnFocus = false;
            this.bunifuImageButton5.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton5.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuImageButton5.ErrorImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton5.ErrorImage")));
            this.bunifuImageButton5.FadeWhenInactive = false;
            this.bunifuImageButton5.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.bunifuImageButton5.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton5.Image")));
            this.bunifuImageButton5.ImageActive = null;
            this.bunifuImageButton5.ImageLocation = null;
            this.bunifuImageButton5.ImageMargin = 75;
            this.bunifuImageButton5.ImageSize = new System.Drawing.Size(64, 73);
            this.bunifuImageButton5.ImageZoomSize = new System.Drawing.Size(139, 148);
            this.bunifuImageButton5.InitialImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton5.InitialImage")));
            this.bunifuImageButton5.Location = new System.Drawing.Point(56, 307);
            this.bunifuImageButton5.Name = "bunifuImageButton5";
            this.bunifuImageButton5.Rotation = 0;
            this.bunifuImageButton5.ShowActiveImage = true;
            this.bunifuImageButton5.ShowCursorChanges = true;
            this.bunifuImageButton5.ShowImageBorders = false;
            this.bunifuImageButton5.ShowSizeMarkers = false;
            this.bunifuImageButton5.Size = new System.Drawing.Size(139, 148);
            this.bunifuImageButton5.TabIndex = 9;
            this.bunifuImageButton5.ToolTipText = "";
            this.bunifuImageButton5.WaitOnLoad = false;
            this.bunifuImageButton5.Zoom = 75;
            this.bunifuImageButton5.ZoomSpeed = 10;
            this.bunifuImageButton5.Click += new System.EventHandler(this.bunifuImageButton5_Click);
            // 
            // bunifuImageButton4
            // 
            this.bunifuImageButton4.ActiveImage = null;
            this.bunifuImageButton4.AllowAnimations = true;
            this.bunifuImageButton4.AllowBuffering = false;
            this.bunifuImageButton4.AllowToggling = false;
            this.bunifuImageButton4.AllowZooming = false;
            this.bunifuImageButton4.AllowZoomingOnFocus = false;
            this.bunifuImageButton4.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton4.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuImageButton4.ErrorImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton4.ErrorImage")));
            this.bunifuImageButton4.FadeWhenInactive = false;
            this.bunifuImageButton4.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.bunifuImageButton4.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton4.Image")));
            this.bunifuImageButton4.ImageActive = null;
            this.bunifuImageButton4.ImageLocation = null;
            this.bunifuImageButton4.ImageMargin = 50;
            this.bunifuImageButton4.ImageSize = new System.Drawing.Size(103, 95);
            this.bunifuImageButton4.ImageZoomSize = new System.Drawing.Size(153, 145);
            this.bunifuImageButton4.InitialImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton4.InitialImage")));
            this.bunifuImageButton4.Location = new System.Drawing.Point(200, 182);
            this.bunifuImageButton4.Name = "bunifuImageButton4";
            this.bunifuImageButton4.Rotation = 0;
            this.bunifuImageButton4.ShowActiveImage = true;
            this.bunifuImageButton4.ShowCursorChanges = true;
            this.bunifuImageButton4.ShowImageBorders = false;
            this.bunifuImageButton4.ShowSizeMarkers = false;
            this.bunifuImageButton4.Size = new System.Drawing.Size(153, 145);
            this.bunifuImageButton4.TabIndex = 8;
            this.bunifuImageButton4.ToolTipText = "";
            this.bunifuImageButton4.WaitOnLoad = false;
            this.bunifuImageButton4.Zoom = 50;
            this.bunifuImageButton4.ZoomSpeed = 10;
            this.bunifuImageButton4.Click += new System.EventHandler(this.bunifuImageButton4_Click);
            // 
            // bunifuImageButton3
            // 
            this.bunifuImageButton3.ActiveImage = null;
            this.bunifuImageButton3.AllowAnimations = true;
            this.bunifuImageButton3.AllowBuffering = false;
            this.bunifuImageButton3.AllowToggling = false;
            this.bunifuImageButton3.AllowZooming = false;
            this.bunifuImageButton3.AllowZoomingOnFocus = false;
            this.bunifuImageButton3.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton3.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuImageButton3.ErrorImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton3.ErrorImage")));
            this.bunifuImageButton3.FadeWhenInactive = false;
            this.bunifuImageButton3.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.bunifuImageButton3.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton3.Image")));
            this.bunifuImageButton3.ImageActive = null;
            this.bunifuImageButton3.ImageLocation = null;
            this.bunifuImageButton3.ImageMargin = 75;
            this.bunifuImageButton3.ImageSize = new System.Drawing.Size(78, 70);
            this.bunifuImageButton3.ImageZoomSize = new System.Drawing.Size(153, 145);
            this.bunifuImageButton3.InitialImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton3.InitialImage")));
            this.bunifuImageButton3.Location = new System.Drawing.Point(49, 179);
            this.bunifuImageButton3.Name = "bunifuImageButton3";
            this.bunifuImageButton3.Rotation = 0;
            this.bunifuImageButton3.ShowActiveImage = true;
            this.bunifuImageButton3.ShowCursorChanges = true;
            this.bunifuImageButton3.ShowImageBorders = false;
            this.bunifuImageButton3.ShowSizeMarkers = false;
            this.bunifuImageButton3.Size = new System.Drawing.Size(153, 145);
            this.bunifuImageButton3.TabIndex = 7;
            this.bunifuImageButton3.ToolTipText = "";
            this.bunifuImageButton3.WaitOnLoad = false;
            this.bunifuImageButton3.Zoom = 75;
            this.bunifuImageButton3.ZoomSpeed = 10;
            this.bunifuImageButton3.Click += new System.EventHandler(this.bunifuImageButton3_Click);
            // 
            // bunifuImageButton2
            // 
            this.bunifuImageButton2.ActiveImage = null;
            this.bunifuImageButton2.AllowAnimations = true;
            this.bunifuImageButton2.AllowBuffering = false;
            this.bunifuImageButton2.AllowToggling = false;
            this.bunifuImageButton2.AllowZooming = false;
            this.bunifuImageButton2.AllowZoomingOnFocus = false;
            this.bunifuImageButton2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton2.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuImageButton2.ErrorImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton2.ErrorImage")));
            this.bunifuImageButton2.FadeWhenInactive = false;
            this.bunifuImageButton2.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.bunifuImageButton2.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton2.Image")));
            this.bunifuImageButton2.ImageActive = null;
            this.bunifuImageButton2.ImageLocation = null;
            this.bunifuImageButton2.ImageMargin = 60;
            this.bunifuImageButton2.ImageSize = new System.Drawing.Size(93, 85);
            this.bunifuImageButton2.ImageZoomSize = new System.Drawing.Size(153, 145);
            this.bunifuImageButton2.InitialImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton2.InitialImage")));
            this.bunifuImageButton2.Location = new System.Drawing.Point(212, 47);
            this.bunifuImageButton2.Name = "bunifuImageButton2";
            this.bunifuImageButton2.Rotation = 0;
            this.bunifuImageButton2.ShowActiveImage = true;
            this.bunifuImageButton2.ShowCursorChanges = true;
            this.bunifuImageButton2.ShowImageBorders = false;
            this.bunifuImageButton2.ShowSizeMarkers = false;
            this.bunifuImageButton2.Size = new System.Drawing.Size(153, 145);
            this.bunifuImageButton2.TabIndex = 6;
            this.bunifuImageButton2.ToolTipText = "";
            this.bunifuImageButton2.WaitOnLoad = false;
            this.bunifuImageButton2.Zoom = 60;
            this.bunifuImageButton2.ZoomSpeed = 10;
            this.bunifuImageButton2.Click += new System.EventHandler(this.bunifuImageButton2_Click);
            // 
            // bunifuImageButton1
            // 
            this.bunifuImageButton1.ActiveImage = null;
            this.bunifuImageButton1.AllowAnimations = true;
            this.bunifuImageButton1.AllowBuffering = false;
            this.bunifuImageButton1.AllowToggling = false;
            this.bunifuImageButton1.AllowZooming = false;
            this.bunifuImageButton1.AllowZoomingOnFocus = false;
            this.bunifuImageButton1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuImageButton1.DialogResult = System.Windows.Forms.DialogResult.None;
            this.bunifuImageButton1.ErrorImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.ErrorImage")));
            this.bunifuImageButton1.FadeWhenInactive = false;
            this.bunifuImageButton1.Flip = Bunifu.UI.WinForms.BunifuImageButton.FlipOrientation.Normal;
            this.bunifuImageButton1.Image = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.Image")));
            this.bunifuImageButton1.ImageActive = null;
            this.bunifuImageButton1.ImageLocation = null;
            this.bunifuImageButton1.ImageMargin = 75;
            this.bunifuImageButton1.ImageSize = new System.Drawing.Size(98, 89);
            this.bunifuImageButton1.ImageZoomSize = new System.Drawing.Size(173, 164);
            this.bunifuImageButton1.InitialImage = ((System.Drawing.Image)(resources.GetObject("bunifuImageButton1.InitialImage")));
            this.bunifuImageButton1.Location = new System.Drawing.Point(57, 39);
            this.bunifuImageButton1.Name = "bunifuImageButton1";
            this.bunifuImageButton1.Rotation = 0;
            this.bunifuImageButton1.ShowActiveImage = true;
            this.bunifuImageButton1.ShowCursorChanges = true;
            this.bunifuImageButton1.ShowImageBorders = false;
            this.bunifuImageButton1.ShowSizeMarkers = false;
            this.bunifuImageButton1.Size = new System.Drawing.Size(173, 164);
            this.bunifuImageButton1.TabIndex = 5;
            this.bunifuImageButton1.ToolTipText = "";
            this.bunifuImageButton1.WaitOnLoad = false;
            this.bunifuImageButton1.Zoom = 75;
            this.bunifuImageButton1.ZoomSpeed = 10;
            this.bunifuImageButton1.Click += new System.EventHandler(this.bunifuImageButton1_Click);
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(37)))), ((int)(((byte)(37)))), ((int)(((byte)(37)))));
            this.panel4.Controls.Add(this.pictureBox1);
            this.panel4.Controls.Add(this.label1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(0, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(359, 49);
            this.panel4.TabIndex = 0;
            this.panel4.Paint += new System.Windows.Forms.PaintEventHandler(this.panel4_Paint);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::APK_Konversi.Properties.Resources.images__1__removebg_preview;
            this.pictureBox1.Location = new System.Drawing.Point(3, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(73, 42);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            this.pictureBox1.Click += new System.EventHandler(this.pictureBox1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Comic Sans MS", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(110, 8);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(171, 32);
            this.label1.TabIndex = 3;
            this.label1.Text = "Menu Konversi";
            // 
            // sidebarTimer1
            // 
            this.sidebarTimer1.Enabled = true;
            this.sidebarTimer1.Interval = 10;
            this.sidebarTimer1.Tick += new System.EventHandler(this.sidebarTimer1_Tick);
            // 
            // bunifuDragControl1
            // 
            this.bunifuDragControl1.Fixed = true;
            this.bunifuDragControl1.Horizontal = true;
            this.bunifuDragControl1.TargetControl = this.panel3;
            this.bunifuDragControl1.Vertical = true;
            // 
            // bunifuDragControl2
            // 
            this.bunifuDragControl2.Fixed = true;
            this.bunifuDragControl2.Horizontal = true;
            this.bunifuDragControl2.TargetControl = this.panel2;
            this.bunifuDragControl2.Vertical = true;
            // 
            // Form2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1075, 663);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form2";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form2";
            this.panel1.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.bunifuPages1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.tabPage7.ResumeLayout(false);
            this.tabPage7.PerformLayout();
            this.tabPage8.ResumeLayout(false);
            this.panel3.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            this.panel4.ResumeLayout(false);
            this.panel4.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel panel5;
        private Bunifu.UI.WinForms.BunifuPages bunifuPages1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private Bunifu.UI.WinForms.BunifuImageButton bunifuImageButton2;
        private Bunifu.UI.WinForms.BunifuImageButton bunifuImageButton1;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private Bunifu.UI.WinForms.BunifuImageButton bunifuImageButton5;
        private Bunifu.UI.WinForms.BunifuImageButton bunifuImageButton4;
        private Bunifu.UI.WinForms.BunifuImageButton bunifuImageButton3;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBoxResult;
        private System.Windows.Forms.TextBox textBoxValue;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.ComboBox comboBox2;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label5;
        private Bunifu.UI.WinForms.BunifuTextBox bunifuTextBox1;
        private System.Windows.Forms.ComboBox comboBox5;
        private System.Windows.Forms.Label label7;
        private Bunifu.UI.WinForms.BunifuTextBox bunifuTextBox5;
        private Bunifu.UI.WinForms.BunifuTextBox bunifuTextBox3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.ComboBox comboBox4;
        private System.Windows.Forms.ComboBox comboBox3;
        private Bunifu.UI.WinForms.BunifuTextBox bunifuTextBox2;
        private Bunifu.UI.WinForms.BunifuTextBox bunifuTextBox4;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox7;
        private System.Windows.Forms.ComboBox comboBox6;
        private System.Windows.Forms.Timer sidebarTimer1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.PictureBox pictureBox2;
        private Bunifu.UI.WinForms.BunifuImageButton bunifuImageButton6;
        private Bunifu.UI.WinForms.BunifuImageButton bunifuImageButton8;
        private Bunifu.UI.WinForms.BunifuImageButton bunifuImageButton7;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl1;
        private Bunifu.Framework.UI.BunifuDragControl bunifuDragControl2;
        private Bunifu.UI.WinForms.BunifuImageButton bunifuImageButton9;
        private System.Windows.Forms.TabPage tabPage6;
        private System.Windows.Forms.ComboBox comboBox8;
        private Bunifu.UI.WinForms.BunifuTextBox bunifuTextBox6;
        private System.Windows.Forms.Label label20;
        private Bunifu.UI.WinForms.BunifuTextBox bunifuTextBox7;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label24;
        private Bunifu.UI.WinForms.BunifuImageButton bunifuImageButton10;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TabPage tabPage7;
        private System.Windows.Forms.TabPage tabPage8;
        private Bunifu.UI.WinForms.BunifuImageButton bunifuImageButton11;
        private Bunifu.UI.WinForms.BunifuTextBox bunifuTextBox9;
        private Bunifu.UI.WinForms.BunifuTextBox bunifuTextBox8;
        private System.Windows.Forms.Label label26;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton OneBtn;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton TwoBtn;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton ThreeBtn;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton FourBtn;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton FiveBtn;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton NineBtn;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton EightBtn;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton SevenBtn;
        private Bunifu.UI.WinForms.BunifuTextBox TxtBox;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton PercentBtn;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton PlusminusBtn;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton MultipleBtn;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton PlusBtn;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton DivideBtn;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton MinusBtn;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton ClearBtn;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton EqualBtn;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton DotBtn;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton ZeroBtn;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton SixBtn;
        private System.Windows.Forms.ComboBox comboBox9;
        private System.Windows.Forms.ComboBox comboBox10;
        private System.Windows.Forms.ComboBox comboBox11;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.ComboBox comboBoxTo;
        private System.Windows.Forms.ComboBox comboBoxFrom;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label43;
        private System.Windows.Forms.ComboBox comboBox12;
        private System.Windows.Forms.Label label44;
    }
}